import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Streamer,
  GiftItem,
  WalletTransaction,
  NotificationItem,
  MessageThread,
  ScreenType,
  LiveComment,
} from '../types';
import {
  INITIAL_USER,
  INITIAL_STREAMERS,
  VIRTUAL_GIFTS,
  INITIAL_TRANSACTIONS,
  INITIAL_NOTIFICATIONS,
  INITIAL_THREADS,
} from '../data/mockData';

import { userService } from '../services/userService';

interface AppContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  currentScreen: ScreenType;
  activeStreamer: Streamer | null;
  streamers: Streamer[];
  isSyncingUsers: boolean;
  gifts: GiftItem[];
  transactions: WalletTransaction[];
  notifications: NotificationItem[];
  messageThreads: MessageThread[];
  activeThreadId: string | null;
  latestGiftBanner: { sender: string; giftName: string; giftIcon: string; count: number } | null;
  floatingHeartsCount: number;
  isVideoCalling: boolean;
  isIncomingCall: boolean;
  incomingCaller: Streamer | null;
  callDuration: number;
  selectedProfileStreamer: Streamer | null;
  // Actions
  refreshUsers: () => Promise<void>;
  setCurrentScreen: (screen: ScreenType) => void;
  setActiveStreamer: (streamer: Streamer | null) => void;
  openUserProfile: (streamer: Streamer) => void;
  closeUserProfile: () => void;
  enterLiveRoom: (streamer: Streamer) => void;
  startVideoCall: (streamer: Streamer) => void;
  triggerIncomingCall: (caller?: Streamer) => void;
  acceptIncomingCall: () => void;
  rejectIncomingCall: () => void;
  endVideoCall: () => void;
  toggleFollow: (streamerId: string) => void;
  sendGift: (gift: GiftItem, streamerId: string, count?: number) => boolean;
  triggerHeart: () => void;
  rechargeCoins: (amount: number, priceLabel: string) => void;
  cashoutDiamonds: (amount: number) => boolean;
  loginUser: (username: string, pass?: string) => Promise<{ success: boolean; error?: string }>;
  signupUser: (username: string, email: string, name: string, bio?: string) => Promise<{ success: boolean; error?: string }>;
  logoutUser: () => void;
  updateProfile: (updated: Partial<User>) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  setActiveThreadId: (id: string | null) => void;
  sendMessageToThread: (threadId: string, text: string) => void;
  startChatWithStreamer: (streamer: Streamer) => void;
  // Device frame toggle
  deviceFrameEnabled: boolean;
  setDeviceFrameEnabled: (enabled: boolean | ((prev: boolean) => boolean)) => void;
}


const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('livestar_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem('livestar_auth');
    return saved !== null ? JSON.parse(saved) : false;
  });

  const [currentScreen, setCurrentScreen] = useState<ScreenType>('home');
  const [activeStreamer, setActiveStreamer] = useState<Streamer | null>(null);
  const [streamers, setStreamers] = useState<Streamer[]>([]);
  const [isSyncingUsers, setIsSyncingUsers] = useState<boolean>(false);

  // Real-time synchronization with shared database
  const refreshUsers = async () => {
    try {
      setIsSyncingUsers(true);
      const fetched = await userService.getAllUsers();
      if (Array.isArray(fetched)) {
        setStreamers(fetched);
        if (fetched.length > 0) {
          setActiveStreamer((prev) => {
            if (!prev) return fetched[0];
            const updatedActive = fetched.find((u) => u.id === prev.id);
            return updatedActive || prev;
          });
        }
      }
    } catch (e) {
      console.warn('[AppContext] Failed to refresh shared users:', e);
    } finally {
      setIsSyncingUsers(false);
    }
  };

  // Poll shared database every 5 seconds so registrations on other devices appear automatically
  useEffect(() => {
    refreshUsers();
    const interval = setInterval(refreshUsers, 5000);
    return () => clearInterval(interval);
  }, []);


  const [transactions, setTransactions] = useState<WalletTransaction[]>(() => {
    const saved = localStorage.getItem('livestar_txs');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('livestar_notifs');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [messageThreads, setMessageThreads] = useState<MessageThread[]>(() => {
    const saved = localStorage.getItem('livestar_threads');
    return saved ? JSON.parse(saved) : INITIAL_THREADS;
  });

  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [latestGiftBanner, setLatestGiftBanner] = useState<{
    sender: string;
    giftName: string;
    giftIcon: string;
    count: number;
  } | null>(null);

  const [floatingHeartsCount, setFloatingHeartsCount] = useState<number>(0);
  const [isVideoCalling, setIsVideoCalling] = useState<boolean>(false);
  const [isIncomingCall, setIsIncomingCall] = useState<boolean>(false);
  const [incomingCaller, setIncomingCaller] = useState<Streamer | null>(null);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [selectedProfileStreamer, setSelectedProfileStreamer] = useState<Streamer | null>(null);
  const [deviceFrameEnabled, setDeviceFrameEnabled] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('livestar_user', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('livestar_auth', JSON.stringify(isAuthenticated));
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem('livestar_streamers', JSON.stringify(streamers));
  }, [streamers]);

  useEffect(() => {
    localStorage.setItem('livestar_txs', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('livestar_notifs', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('livestar_threads', JSON.stringify(messageThreads));
  }, [messageThreads]);

  // Video call timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isVideoCalling && !isIncomingCall) {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isVideoCalling, isIncomingCall]);

  const enterLiveRoom = (streamer: Streamer) => {
    setActiveStreamer(streamer);
    setCurrentScreen('live_room');
  };

  const startVideoCall = (streamer: Streamer) => {
    setActiveStreamer(streamer);
    setIsVideoCalling(true);
    setIsIncomingCall(false);
    setIncomingCaller(null);
    setCurrentScreen('video_call');
  };

  const triggerIncomingCall = (caller?: Streamer) => {
    const callerStreamer = caller || streamers[0] || INITIAL_STREAMERS[0];
    setIncomingCaller(callerStreamer);
    setIsIncomingCall(true);
  };

  const acceptIncomingCall = () => {
    if (incomingCaller) {
      setActiveStreamer(incomingCaller);
    }
    setIsIncomingCall(false);
    setIsVideoCalling(true);
    setCallDuration(0);
    setCurrentScreen('video_call');
  };

  const rejectIncomingCall = () => {
    const callerName = incomingCaller?.displayName || 'Streamer';
    const callerAvatar = incomingCaller?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80';
    const callerId = incomingCaller?.id;

    setIsIncomingCall(false);
    setIncomingCaller(null);

    // Record a missed call notification
    const missedNotif: NotificationItem = {
      id: `notif_missed_${Date.now()}`,
      type: 'message',
      title: `Missed Video Call`,
      message: `Declined 1-on-1 video call invitation from ${callerName}.`,
      avatar: callerAvatar,
      timestamp: 'Just now',
      isRead: false,
      actionScreen: 'inbox',
      streamerId: callerId,
    };
    setNotifications((prev) => [missedNotif, ...prev]);
  };

  const endVideoCall = () => {
    setIsVideoCalling(false);
    setIsIncomingCall(false);
    setIncomingCaller(null);
    setCallDuration(0);
    setCurrentScreen('home');
  };

  const openUserProfile = (streamer: Streamer) => {
    setSelectedProfileStreamer(streamer);
  };

  const closeUserProfile = () => {
    setSelectedProfileStreamer(null);
  };

  const toggleFollow = (streamerId: string) => {
    setStreamers((prev) =>
      prev.map((s) => {
        if (s.id === streamerId) {
          const nextState = !s.isFollowing;
          return {
            ...s,
            isFollowing: nextState,
            followersCount: s.followersCount + (nextState ? 1 : -1),
          };
        }
        return s;
      })
    );

    if (activeStreamer && activeStreamer.id === streamerId) {
      setActiveStreamer((prev) =>
        prev
          ? {
              ...prev,
              isFollowing: !prev.isFollowing,
              followersCount: prev.followersCount + (!prev.isFollowing ? 1 : -1),
            }
          : null
      );
    }

    if (currentUser) {
      setCurrentUser((prev) =>
        prev
          ? {
              ...prev,
              followingCount: prev.followingCount + 1,
            }
          : null
      );
    }
  };

  const sendGift = (gift: GiftItem, streamerId: string, count = 1): boolean => {
    if (!currentUser) {
      setCurrentScreen('auth');
      return false;
    }

    const totalCost = gift.cost * count;
    if (currentUser.coinsCount < totalCost) {
      return false;
    }

    // Deduct coins from user
    setCurrentUser((prev) => (prev ? { ...prev, coinsCount: prev.coinsCount - totalCost } : null));

    // Increase streamer diamond stats
    const targetStreamer = streamers.find((s) => s.id === streamerId);
    setStreamers((prev) =>
      prev.map((s) => (s.id === streamerId ? { ...s, diamondsEarned: s.diamondsEarned + totalCost } : s))
    );

    if (activeStreamer && activeStreamer.id === streamerId) {
      setActiveStreamer((prev) =>
        prev ? { ...prev, diamondsEarned: prev.diamondsEarned + totalCost } : null
      );
    }

    // Record wallet transaction
    const newTx: WalletTransaction = {
      id: `tx_${Date.now()}`,
      type: 'gift_sent',
      title: `Sent ${count > 1 ? `${count}x ` : ''}${gift.name}`,
      subtitle: `To @${targetStreamer?.displayName || 'Streamer'} · Live Room`,
      amountCoins: -totalCost,
      timestamp: 'Just now',
    };
    setTransactions((prev) => [newTx, ...prev]);

    // Show floating announcement banner
    setLatestGiftBanner({
      sender: currentUser.displayName,
      giftName: gift.name,
      giftIcon: gift.icon,
      count,
    });

    setTimeout(() => {
      setLatestGiftBanner(null);
    }, 4000);

    return true;
  };

  const triggerHeart = () => {
    setFloatingHeartsCount((prev) => prev + 1);
    if (activeStreamer) {
      setActiveStreamer((prev) => (prev ? { ...prev, likesCount: prev.likesCount + 1 } : null));
    }
  };

  const rechargeCoins = (amount: number, priceLabel: string) => {
    if (!currentUser) return;
    setCurrentUser((prev) => (prev ? { ...prev, coinsCount: prev.coinsCount + amount } : null));

    const newTx: WalletTransaction = {
      id: `tx_${Date.now()}`,
      type: 'recharge',
      title: `Coins Recharge (+${amount.toLocaleString()} Coins)`,
      subtitle: `Instant Demo Top-up · ${priceLabel}`,
      amountCoins: amount,
      timestamp: 'Just now',
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const cashoutDiamonds = (amount: number): boolean => {
    if (!currentUser || currentUser.diamondsCount < amount) return false;
    setCurrentUser((prev) => (prev ? { ...prev, diamondsCount: prev.diamondsCount - amount } : null));

    const estimatedUSD = (amount / 200).toFixed(2);
    const newTx: WalletTransaction = {
      id: `tx_${Date.now()}`,
      type: 'cashout',
      title: `Creator Payout ($${estimatedUSD} USD)`,
      subtitle: `Redeemed ${amount.toLocaleString()} Diamonds to PayPal`,
      amountCoins: 0,
      amountDiamonds: -amount,
      timestamp: 'Just now',
    };
    setTransactions((prev) => [newTx, ...prev]);
    return true;
  };

  const loginUser = async (username: string, _pass?: string): Promise<{ success: boolean; error?: string }> => {
    const res = await userService.login(username);
    if (!res.success || !res.user) {
      return { success: false, error: res.error || 'Login failed' };
    }

    const userObj: User = {
      id: res.user.id,
      username: res.user.username,
      displayName: res.user.displayName,
      avatar: res.user.avatar,
      bio: res.user.bio,
      followersCount: res.user.followersCount || 0,
      followingCount: res.user.followingCount || 0,
      streamsCount: res.user.streamsCount || 0,
      diamondsCount: res.user.diamondsCount || 0,
      coinsCount: res.user.coinsCount || 500,
      level: res.user.level || 1,

      isVerified: Boolean(res.user.isVerified),
      coverBanner: res.user.coverImage,
    };

    setCurrentUser(userObj);
    setIsAuthenticated(true);
    setCurrentScreen('home');
    await refreshUsers();
    return { success: true };
  };

  const signupUser = async (
    username: string,
    email: string,
    name: string,
    bio?: string
  ): Promise<{ success: boolean; error?: string }> => {
    const res = await userService.register({
      username,
      displayName: name,
      email,
      bio,
    });

    if (!res.success || !res.user) {
      return { success: false, error: res.error || 'Registration failed' };
    }

    const userObj: User = {
      id: res.user.id,
      username: res.user.username,
      displayName: res.user.displayName,
      avatar: res.user.avatar,
      bio: res.user.bio,
      followersCount: 0,
      followingCount: 0,
      streamsCount: 0,
      diamondsCount: 0,
      coinsCount: 500,
      level: 1,
      isVerified: false,
      coverBanner: res.user.coverImage,
    };

    setCurrentUser(userObj);
    setIsAuthenticated(true);
    setCurrentScreen('home');
    await refreshUsers();
    return { success: true };
  };

  const logoutUser = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    localStorage.removeItem('livestar_user');
    localStorage.removeItem('livestar_auth');
    setCurrentScreen('auth');
  };

  const updateProfile = async (updated: Partial<User>) => {
    if (!currentUser) return;
    setCurrentUser((prev) => (prev ? { ...prev, ...updated } : null));
    try {
      await fetch(`/api/users/${currentUser.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      await refreshUsers();
    } catch (err) {
      console.warn('Failed to sync profile update:', err);
    }
  };


  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const sendMessageToThread = (threadId: string, text: string) => {
    if (!text.trim() || !currentUser) return;

    const newMsg = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      text: text.trim(),
      timestamp: 'Just now',
      isMe: true,
    };

    setMessageThreads((prev) =>
      prev.map((th) => {
        if (th.id === threadId) {
          return {
            ...th,
            lastMessage: text.trim(),
            lastTimestamp: 'Just now',
            messages: [...th.messages, newMsg],
          };
        }
        return th;
      })
    );
  };

  const startChatWithStreamer = (streamer: Streamer) => {
    let thread = messageThreads.find((th) => th.streamerId === streamer.id);
    if (!thread) {
      const newThread: MessageThread = {
        id: `th_${Date.now()}`,
        streamerId: streamer.id,
        streamerName: streamer.displayName,
        streamerAvatar: streamer.avatar,
        isOnline: true,
        lastMessage: 'Started conversation',
        lastTimestamp: 'Just now',
        unreadCount: 0,
        messages: [
          {
            id: `m_${Date.now()}`,
            senderId: streamer.id,
            text: `Hi ${currentUser?.displayName || 'there'}! Thanks for connecting. How are you liking the stream?`,
            timestamp: 'Just now',
            isMe: false,
          },
        ],
      };
      setMessageThreads((prev) => [newThread, ...prev]);
      setActiveThreadId(newThread.id);
    } else {
      setActiveThreadId(thread.id);
    }
    setCurrentScreen('inbox');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        currentScreen,
        activeStreamer,
        streamers,
        isSyncingUsers,
        refreshUsers,
        gifts: VIRTUAL_GIFTS,
        transactions,
        notifications,
        messageThreads,
        activeThreadId,
        latestGiftBanner,
        floatingHeartsCount,
        isVideoCalling,
        isIncomingCall,
        incomingCaller,
        callDuration,
        selectedProfileStreamer,
        setCurrentScreen,
        setActiveStreamer,

        openUserProfile,
        closeUserProfile,
        enterLiveRoom,
        startVideoCall,
        triggerIncomingCall,
        acceptIncomingCall,
        rejectIncomingCall,
        endVideoCall,
        toggleFollow,
        sendGift,
        triggerHeart,
        rechargeCoins,
        cashoutDiamonds,
        loginUser,
        signupUser,
        logoutUser,
        updateProfile,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        setActiveThreadId,
        sendMessageToThread,
        startChatWithStreamer,
        deviceFrameEnabled,
        setDeviceFrameEnabled,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
