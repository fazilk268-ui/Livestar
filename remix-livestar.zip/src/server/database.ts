import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface RegisteredUser {
  id: string; // Unique, permanent user ID (e.g. usr_3f8a12bc90de44ab)
  username: string; // Unique lowercase handle
  displayName: string;
  email: string;
  avatar: string;
  coverImage: string;
  bio: string;
  title: string;
  category: 'Popular' | 'Music' | 'Gaming' | 'Chat' | 'PK Battle';
  tags: string[];
  followersCount: number;
  followingCount: number;
  streamsCount: number;
  diamondsCount: number;
  coinsCount: number;
  level: number;
  isVerified: boolean;
  isLive: boolean;
  viewersCount: number;
  likesCount: number;
  diamondsEarned: number;
  createdAt: string;
  updatedAt: string;
  lastActive: string;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'users.json');

// Ensure database directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-memory cache of registered users
let usersCache: RegisteredUser[] = [];

/**
 * Loads users from disk into cache.
 */
function loadDatabase(): RegisteredUser[] {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        usersCache = parsed;
        return usersCache;
      }
    }
  } catch (err) {
    console.error('Error reading shared users database:', err);
  }
  // Initialize with empty database (no hardcoded users)
  usersCache = [];
  saveDatabase();
  return usersCache;
}

/**
 * Saves users cache to disk synchronously.
 */
function saveDatabase(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(usersCache, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving shared users database:', err);
  }
}

// Initialize on module load
loadDatabase();

/**
 * Generates an avatar URL if user didn't provide one.
 */
function generateDefaultAvatar(seed: string): string {
  const cleanSeed = encodeURIComponent(seed.toLowerCase().trim() || 'user');
  return `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${cleanSeed}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf`;
}

/**
 * Generates a default cover image.
 */
function generateDefaultCover(): string {
  const covers = [
    'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
  ];
  return covers[Math.floor(Math.random() * covers.length)];
}

export const SharedUserDatabase = {
  /**
   * Returns all registered users in the shared database.
   */
  getAllUsers(): RegisteredUser[] {
    loadDatabase();
    return [...usersCache].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  },

  /**
   * Search registered users by query string across username, displayName, bio, or tags.
   */
  searchUsers(query: string): RegisteredUser[] {
    loadDatabase();
    const cleanQ = (query || '').toLowerCase().trim();
    if (!cleanQ) return this.getAllUsers();

    return usersCache.filter((u) => {
      const matchUsername = u.username.toLowerCase().includes(cleanQ);
      const matchName = u.displayName.toLowerCase().includes(cleanQ);
      const matchBio = (u.bio || '').toLowerCase().includes(cleanQ);
      const matchTitle = (u.title || '').toLowerCase().includes(cleanQ);
      const matchTags = (u.tags || []).some((t) => t.toLowerCase().includes(cleanQ));
      const matchId = u.id.toLowerCase().includes(cleanQ);
      return matchUsername || matchName || matchBio || matchTitle || matchTags || matchId;
    });
  },

  /**
   * Finds a user by ID.
   */
  getUserById(id: string): RegisteredUser | null {
    loadDatabase();
    return usersCache.find((u) => u.id === id) || null;
  },

  /**
   * Finds a user by handle/username (case-insensitive).
   */
  getUserByUsername(username: string): RegisteredUser | null {
    loadDatabase();
    const clean = (username || '').toLowerCase().trim();
    return usersCache.find((u) => u.username.toLowerCase() === clean) || null;
  },

  /**
   * Registers a new user with a unique ID and validates username uniqueness.
   */
  registerUser(data: {
    username: string;
    displayName: string;
    email?: string;
    avatar?: string;
    bio?: string;
    title?: string;
    category?: 'Popular' | 'Music' | 'Gaming' | 'Chat' | 'PK Battle';
  }): { success: true; user: RegisteredUser } | { success: false; error: string } {
    loadDatabase();

    const cleanUsername = (data.username || '')
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9_]/g, '');

    if (!cleanUsername || cleanUsername.length < 2) {
      return { success: false, error: 'Username must be at least 2 alphanumeric characters.' };
    }

    const cleanName = (data.displayName || '').trim() || cleanUsername;

    // Check if username already exists in shared database
    const existing = usersCache.find((u) => u.username.toLowerCase() === cleanUsername);
    if (existing) {
      return {
        success: false,
        error: `Username "@${cleanUsername}" is already taken by another user. Please choose a different username.`,
      };
    }

    // Generate unique user ID: 'usr_' + 16 random hex characters (8 bytes)
    const uniqueId = `usr_${crypto.randomBytes(8).toString('hex')}`;
    const now = new Date().toISOString();

    const newUser: RegisteredUser = {
      id: uniqueId,
      username: cleanUsername,
      displayName: cleanName,
      email: (data.email || `${cleanUsername}@livestar.live`).trim().toLowerCase(),
      avatar: data.avatar?.trim() || generateDefaultAvatar(cleanUsername),
      coverImage: generateDefaultCover(),
      bio: data.bio?.trim() || `Creator on LiveStar 🌟 ID: ${uniqueId}`,
      title: data.title?.trim() || `Streaming live on LiveStar!`,
      category: data.category || 'Popular',
      tags: ['LiveStar', 'Creator'],
      followersCount: 0,
      followingCount: 0,
      streamsCount: 0,
      diamondsCount: 0,
      coinsCount: 500, // Welcome coins bonus
      level: 1,
      isVerified: false,
      isLive: true,
      viewersCount: Math.floor(Math.random() * 50) + 5,
      likesCount: 0,
      diamondsEarned: 0,
      createdAt: now,
      updatedAt: now,
      lastActive: now,
    };

    usersCache.unshift(newUser);
    saveDatabase();

    console.log(`[SharedDatabase] New user registered: ${newUser.displayName} (@${newUser.username}, ID: ${newUser.id})`);
    return { success: true, user: newUser };
  },

  /**
   * Authenticates user by username handle.
   */
  loginUser(username: string): { success: true; user: RegisteredUser } | { success: false; error: string } {
    loadDatabase();
    const cleanUsername = (username || '').toLowerCase().trim().replace(/^@/, '');
    const user = usersCache.find((u) => u.username.toLowerCase() === cleanUsername);

    if (!user) {
      return {
        success: false,
        error: `No registered account found with handle "@${cleanUsername}". Please register first.`,
      };
    }

    user.lastActive = new Date().toISOString();
    user.updatedAt = new Date().toISOString();
    saveDatabase();

    return { success: true, user };
  },

  /**
   * Updates an existing user profile.
   */
  updateUser(
    id: string,
    updates: Partial<RegisteredUser>
  ): { success: true; user: RegisteredUser } | { success: false; error: string } {
    loadDatabase();
    const user = usersCache.find((u) => u.id === id);
    if (!user) {
      return { success: false, error: 'User not found' };
    }

    // Protect immutable identity fields
    delete (updates as any).id;
    delete (updates as any).username;
    delete (updates as any).createdAt;

    Object.assign(user, updates, { updatedAt: new Date().toISOString() });
    saveDatabase();
    return { success: true, user };
  },

  /**
   * Toggles follow status between follower and target user.
   */
  toggleFollow(
    targetUserId: string,
    followerUserId: string
  ): { success: true; isFollowing: boolean; targetFollowers: number } | { success: false; error: string } {
    loadDatabase();
    const target = usersCache.find((u) => u.id === targetUserId);
    const follower = usersCache.find((u) => u.id === followerUserId);

    if (!target) {
      return { success: false, error: 'Target user not found' };
    }

    // Toggle logic: increment by 1
    target.followersCount = Math.max(0, target.followersCount + 1);
    if (follower) {
      follower.followingCount = Math.max(0, follower.followingCount + 1);
    }
    saveDatabase();

    return { success: true, isFollowing: true, targetFollowers: target.followersCount };
  },

  /**
   * Seeds clean starter community members if the database is brand new.
   * This provides instant discovery while ensuring each user has a unique ID
   * and is stored entirely in the shared database.
   */
  seedInitialUsersIfEmpty(): void {
    loadDatabase();
    if (usersCache.length > 0) return;

    console.log('[SharedDatabase] Seeding initial registered community users in shared database...');
    const seedList = [
      {
        username: 'dj_aura',
        displayName: 'DJ Aura',
        avatar: '/src/assets/images/streamer_dj_neon_1794011769075.jpg',
        title: '🎧 Friday Night Club Mix & Live Remix Session!',
        category: 'Music' as const,
        bio: 'Electronic producer & live club resident DJ. Catch the live beats!',
      },
      {
        username: 'kai_arcade',
        displayName: 'Kai Arcade',
        avatar: '/src/assets/images/streamer_gaming_host_1794011769419.jpg',
        title: '🏆 Ranked Grind to Grandmaster! 1v1 Viewers',
        category: 'Gaming' as const,
        bio: 'Competitive gamer, streamer & gear reviewer.',
      },
      {
        username: 'sarah_acoustic',
        displayName: 'Sarah Acoustic',
        avatar: '/src/assets/images/streamer_singer_acoustic_1794011769537.jpg',
        title: '✨ Late Night Coffee & Guitar Requests | Cozy Concert',
        category: 'Music' as const,
        bio: 'Singer-songwriter with an acoustic guitar. Singing your favorites.',
      },
      {
        username: 'elena_stylelab',
        displayName: 'Elena StyleLab',
        avatar: '/src/assets/images/streamer_fashion_creator_1794011770267.jpg',
        title: '💄 Fashion Week Breakdown & Live Styling Q&A',
        category: 'Chat' as const,
        bio: 'Creative director & stylist exploring futuristic streetwear.',
      },
    ];

    for (const item of seedList) {
      this.registerUser(item);
    }
  },
};

// Seed initial users if database is empty so discovery has users on first run
SharedUserDatabase.seedInitialUsersIfEmpty();
