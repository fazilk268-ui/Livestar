import React, { useState } from 'react';
import {
  Settings,
  Edit3,
  Award,
  Flame,
  Coins,
  Sparkles,
  MapPin,
  CheckCircle,
  Share2,
  LogOut,
  Video,
  Grid,
  Trophy,
  Heart,
  ChevronRight,
  X,
  Save,
  PhoneCall,
  PhoneIncoming,
  Radio,
  UserCheck,
  Shield,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ProfileScreen: React.FC = () => {
  const {
    currentUser,
    updateProfile,
    logoutUser,
    setCurrentScreen,
    gifts,
    streamers,
    startVideoCall,
    triggerIncomingCall,
    openUserProfile,
  } = useApp();
  const [activeTab, setActiveTab] = useState<'calls' | 'streams' | 'gifts' | 'badges'>('calls');
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);

  // Edit form state
  const [editName, setEditName] = useState(currentUser?.displayName || '');
  const [editBio, setEditBio] = useState(currentUser?.bio || '');
  const [editLocation, setEditLocation] = useState(currentUser?.location || 'Tokyo, Japan');

  if (!currentUser) {
    return (
      <div className="p-6 text-center">
        <p className="text-slate-400 mb-4">Please log in to view profile</p>
        <button
          onClick={() => setCurrentScreen('auth')}
          className="px-4 py-2 rounded-xl bg-pink-600 text-white font-bold"
        >
          Sign In
        </button>
      </div>
    );
  }

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      displayName: editName.trim() || currentUser.displayName,
      bio: editBio.trim() || currentUser.bio,
      location: editLocation.trim() || currentUser.location,
    });
    setIsEditModalOpen(false);
  };

  const sampleBadges = [
    { name: 'VIP Patron Lv.18', desc: 'Active supporter across 20+ live streams', icon: '👑', color: 'from-amber-400 to-yellow-600' },
    { name: 'Super Gifter', desc: 'Sent over 5,000 platform coins in gifts', icon: '🚀', color: 'from-purple-500 to-pink-600' },
    { name: 'Night Owl DJ Club', desc: 'Streamed 10+ late night music sessions', icon: '🎧', color: 'from-blue-500 to-cyan-600' },
    { name: 'Early Adopter', desc: 'Founding member of LiveStar community', icon: '⭐', color: 'from-pink-500 to-rose-600' },
  ];

  return (
    <div className="pb-24 pt-2 px-3 max-w-lg mx-auto space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <h1 className="font-display font-bold text-lg text-white">My Creator Profile</h1>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
            title="Edit Profile"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={logoutUser}
            className="p-2 rounded-full bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Hero Profile Card */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-b from-[#171b30] to-[#0f1222] border border-white/10 p-4 space-y-3 shadow-xl">
        <div className="flex items-start gap-3.5">
          {/* Avatar with Level Ring */}
          <div className="relative shrink-0">
            <div className="w-18 h-18 rounded-full p-[2.5px] bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-600 shadow-lg shadow-pink-500/20">
              <img
                src={currentUser.avatar}
                alt={currentUser.displayName}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            <div className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full bg-purple-600 text-[10px] font-extrabold text-white border border-black shadow">
              Lv.{currentUser.level}
            </div>
          </div>

          {/* Name & Handle */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h2 className="text-base font-bold text-white truncate">
                {currentUser.displayName}
              </h2>
              {currentUser.isVerified && (
                <CheckCircle className="w-4 h-4 text-pink-400 fill-pink-400 shrink-0" />
              )}
            </div>
            <p className="text-xs text-slate-400">@{currentUser.username}</p>
            <div className="mt-1 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/40 border border-white/10 text-[10px] font-mono text-purple-300">
              <Shield className="w-3 h-3 text-emerald-400" />
              <span>ID: {currentUser.id}</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(currentUser.id);
                }}
                className="hover:text-white ml-0.5"
                title="Copy User ID"
              >
                📋
              </button>
            </div>
            {currentUser.location && (
              <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-1">
                <MapPin className="w-3 h-3 text-pink-400" />
                <span>{currentUser.location}</span>
              </div>
            )}

          </div>
        </div>

        {/* Bio */}
        <p className="text-xs text-slate-200 leading-relaxed bg-white/5 p-2.5 rounded-xl border border-white/5">
          {currentUser.bio}
        </p>

        {/* Stats Strip */}
        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-white/5 text-center">
          <div className="p-2 rounded-xl bg-white/5">
            <span className="block text-sm font-bold text-white tabular-nums">
              {currentUser.followersCount.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400">Followers</span>
          </div>

          <div className="p-2 rounded-xl bg-white/5">
            <span className="block text-sm font-bold text-white tabular-nums">
              {currentUser.followingCount.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400">Following</span>
          </div>

          <div className="p-2 rounded-xl bg-white/5">
            <span className="block text-sm font-bold text-pink-400 tabular-nums">
              {currentUser.streamsCount}
            </span>
            <span className="text-[10px] text-slate-400">Streams</span>
          </div>

          <div className="p-2 rounded-xl bg-white/5">
            <span className="block text-sm font-bold text-amber-300 tabular-nums">
              {(currentUser.diamondsCount / 1000).toFixed(1)}k
            </span>
            <span className="text-[10px] text-slate-400">Diamonds</span>
          </div>
        </div>
      </div>

      {/* Wallet Balance Shortcut Card */}
      <div
        onClick={() => setCurrentScreen('wallet')}
        className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/40 via-pink-900/30 to-amber-900/20 border border-pink-500/20 flex items-center justify-between cursor-pointer hover:border-pink-500/40 transition-all shadow-md group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-pink-500 flex items-center justify-center text-slate-950 font-black shadow-md">
            <Coins className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white">LiveStar Coin Wallet</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 font-bold border border-amber-400/30">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5">
              <span className="text-amber-300 font-bold tabular-nums">
                {currentUser.coinsCount.toLocaleString()} Coins
              </span>{' '}
              ·{' '}
              <span className="text-purple-300 font-bold tabular-nums">
                {currentUser.diamondsCount.toLocaleString()} Diamonds
              </span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-xs text-pink-400 font-semibold group-hover:translate-x-0.5 transition-transform">
          <span>Recharge</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>

      {/* Segmented Tabs */}
      <div className="flex items-center p-1 bg-white/5 rounded-2xl border border-white/5">
        <button
          onClick={() => setActiveTab('calls')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1 ${
            activeTab === 'calls'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <PhoneCall className="w-3.5 h-3.5" />
          <span>1v1 Calls</span>
        </button>

        <button
          onClick={() => setActiveTab('streams')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1 ${
            activeTab === 'streams'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Video className="w-3.5 h-3.5" />
          <span>Streams</span>
        </button>

        <button
          onClick={() => setActiveTab('gifts')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1 ${
            activeTab === 'gifts'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>Gifts</span>
        </button>

        <button
          onClick={() => setActiveTab('badges')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1 ${
            activeTab === 'badges'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Trophy className="w-3.5 h-3.5" />
          <span>Badges</span>
        </button>
      </div>

      {/* Tab Content: 1v1 VIDEO CALLING */}
      {activeTab === 'calls' && (
        <div className="space-y-3">
          {/* Incoming Call Tester Card */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/30 via-pink-900/30 to-black/40 border border-purple-500/30 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center">
                  <PhoneIncoming className="w-4 h-4 animate-bounce" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Incoming Call Simulation</h4>
                  <p className="text-[10px] text-slate-300">Test incoming video call screen with Accept / Reject</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => triggerIncomingCall(streamers[0])}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 active:scale-[0.98] transition-all"
            >
              <PhoneIncoming className="w-3.5 h-3.5 text-amber-300" />
              <span>Simulate Incoming Call from DJ Aura</span>
            </button>
          </div>

          {/* Creators List with Start Video Call Buttons */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-bold text-slate-300">Top Creators Available for 1-on-1 Call</span>
              <span className="text-[10px] text-pink-400 font-semibold">Instant HD Connect</span>
            </div>

            {streamers.map((streamer) => (
              <div
                key={streamer.id}
                className="p-3 rounded-2xl bg-white/5 border border-white/5 hover:border-pink-500/30 transition-all flex items-center justify-between gap-2.5"
              >
                {/* Creator Avatar & Info */}
                <div
                  onClick={() => openUserProfile(streamer)}
                  className="flex items-center gap-2.5 min-w-0 cursor-pointer group flex-1"
                >
                  <div className="relative shrink-0">
                    <img
                      src={streamer.avatar}
                      alt={streamer.displayName}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover border border-pink-400 group-hover:scale-105 transition-transform"
                    />
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#080911]" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <h4 className="text-xs font-bold text-white truncate group-hover:text-pink-300 transition-colors">
                        {streamer.displayName}
                      </h4>
                      <CheckCircle className="w-3 h-3 text-pink-400 shrink-0" />
                    </div>
                    <p className="text-[10px] text-slate-400 truncate">
                      {streamer.category} · {(streamer.followersCount / 1000).toFixed(1)}k followers
                    </p>
                  </div>
                </div>

                {/* START VIDEO CALL BUTTON */}
                <button
                  onClick={() => startVideoCall(streamer)}
                  className="px-3 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-pink-500/20 active:scale-95 transition-all shrink-0"
                  title={`Start video call with ${streamer.displayName}`}
                >
                  <PhoneCall className="w-3.5 h-3.5 text-amber-200" />
                  <span>Call</span>
                </button>
              </div>
            ))}
          </div>

          {/* Agora RTC Engine & Android Setup Card */}
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-emerald-400" />
                <span>Agora RTC Integration Info</span>
              </span>
              <span className="text-[10px] text-pink-300 font-mono bg-pink-500/10 px-2 py-0.5 rounded-full border border-pink-500/20 font-bold">
                App ID Configured
              </span>
            </div>

            <div className="space-y-1 text-[11px] text-slate-300">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">App ID:</span>
                <span className="font-mono text-purple-300 text-[10px]">
                  c4a9cf6f9245456b929b79923f713952
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Token Endpoint:</span>
                <span className="font-mono text-emerald-400 text-[10px]">
                  POST /api/agora/token
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Security Mode:</span>
                <span className="text-slate-200">Backend Token Authorization</span>
              </div>
            </div>

            <div className="pt-2 border-t border-white/5 space-y-1.5">
              <span className="text-[11px] font-bold text-pink-300 block">
                Android Integration Steps (3 Simple Steps):
              </span>
              <ol className="text-[10px] text-slate-300 space-y-1 list-decimal list-inside leading-relaxed">
                <li>
                  Add <code className="text-pink-300">io.agora.rtc:full-sdk:4.x</code> to your Android <code className="text-slate-200">build.gradle</code>.
                </li>
                <li>
                  Initialize <code className="text-purple-300">RtcEngine.create(context, "c4a9cf6f9245456b929b79923f713952", mRtcEventHandler)</code>.
                </li>
                <li>
                  Call your server endpoint <code className="text-emerald-400">POST /api/agora/token</code> with the channel name and join with <code className="text-pink-300">rtcEngine.joinChannel(token, channelName, "", uid)</code>.
                </li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* Tab Content: STREAMS */}
      {activeTab === 'streams' && (
        <div className="space-y-2">
          <div className="p-3 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-purple-900/40 border border-purple-500/30 flex items-center justify-center text-pink-400">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Late Night Beats & Synth Replay</h4>
                <p className="text-[11px] text-slate-400">3 days ago · 3,420 Viewers · 420 Diamonds</p>
              </div>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full font-bold">
              Saved
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-pink-900/40 border border-pink-500/30 flex items-center justify-center text-pink-400">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Live Q&A: Audio Gear Tour 2026</h4>
                <p className="text-[11px] text-slate-400">1 week ago · 2,890 Viewers · 310 Diamonds</p>
              </div>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full font-bold">
              Saved
            </span>
          </div>

          <button
            onClick={() => setCurrentScreen('go_live')}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-500/20 active:scale-[0.98] transition-all"
          >
            <Video className="w-4 h-4" />
            <span>Start a New Live Stream</span>
          </button>
        </div>
      )}

      {activeTab === 'gifts' && (
        <div className="grid grid-cols-4 gap-2.5">
          {gifts.map((gift) => (
            <div
              key={gift.id}
              className="p-3 rounded-2xl bg-white/5 border border-white/5 flex flex-col items-center justify-center text-center space-y-1 hover:border-pink-500/30 transition-colors"
            >
              <span className="text-2xl">{gift.icon}</span>
              <span className="text-[10px] font-bold text-white truncate w-full">{gift.name}</span>
              <span className="text-[9px] text-slate-400">Unlocked</span>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'badges' && (
        <div className="space-y-2">
          {sampleBadges.map((badge, idx) => (
            <div
              key={idx}
              className="p-3 rounded-2xl bg-white/5 border border-white/5 flex items-center gap-3"
            >
              <div
                className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${badge.color} flex items-center justify-center text-lg shadow-md shrink-0`}
              >
                {badge.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-white truncate">{badge.name}</h4>
                <p className="text-[11px] text-slate-400 leading-snug">{badge.desc}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* EDIT PROFILE MODAL */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#121626] rounded-3xl border border-white/15 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h3 className="font-display font-bold text-sm text-white">Edit Creator Profile</h3>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white focus:outline-none focus:border-pink-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Bio</label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white focus:outline-none focus:border-pink-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Location
                </label>
                <input
                  type="text"
                  value={editLocation}
                  onChange={(e) => setEditLocation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white focus:outline-none focus:border-pink-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-pink-500/20"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
