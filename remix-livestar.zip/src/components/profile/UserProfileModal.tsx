import React, { useState } from 'react';
import {
  X,
  PhoneCall,
  Video,
  MessageCircle,
  Gift,
  Heart,
  CheckCircle,
  UserPlus,
  UserCheck,
  Flame,
  Users,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GiftModal } from '../live/GiftModal';

export const UserProfileModal: React.FC = () => {
  const {
    selectedProfileStreamer,
    closeUserProfile,
    startVideoCall,
    toggleFollow,
    startChatWithStreamer,
    enterLiveRoom,
  } = useApp();

  const [isGiftModalOpen, setIsGiftModalOpen] = useState(false);

  if (!selectedProfileStreamer) return null;

  const streamer = selectedProfileStreamer;

  const handleStartCall = () => {
    closeUserProfile();
    startVideoCall(streamer);
  };

  const handleOpenChat = () => {
    closeUserProfile();
    startChatWithStreamer(streamer);
  };

  const handleWatchLive = () => {
    closeUserProfile();
    enterLiveRoom(streamer);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200 select-none">
      <div className="w-full max-w-sm rounded-t-[36px] sm:rounded-[36px] bg-[#101324] border border-white/15 p-5 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto no-scrollbar">
        {/* Grab Handle for mobile */}
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mb-3 sm:hidden" />

        {/* Top Header */}
        <div className="flex items-center justify-between pb-2">
          <span className="text-xs font-bold text-pink-400 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Creator Profile</span>
          </span>
          <button
            onClick={closeUserProfile}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile Header & Avatar */}
        <div className="flex flex-col items-center text-center space-y-2.5 my-2">
          <div className="relative">
            <div className="w-22 h-22 rounded-full p-1 bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-600 shadow-xl shadow-pink-500/30">
              <img
                src={streamer.avatar}
                alt={streamer.displayName}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            {streamer.isLive && (
              <span className="absolute bottom-0 right-1 px-2 py-0.5 rounded-full bg-pink-600 text-white text-[9px] font-black border-2 border-[#101324] animate-pulse">
                LIVE
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center justify-center gap-1.5">
              <h2 className="text-lg font-bold text-white">{streamer.displayName}</h2>
              <CheckCircle className="w-4 h-4 text-pink-400 fill-pink-400 shrink-0" />
            </div>
            <p className="text-xs text-slate-400">@{streamer.username}</p>
            <div className="mt-1 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/40 border border-white/10 text-[10px] font-mono text-purple-300">
              <span>ID: {streamer.id}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  navigator.clipboard.writeText(streamer.id);
                }}
                className="hover:text-white p-0.5"
                title="Copy User ID"
              >
                📋
              </button>
            </div>
          </div>


          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-2 w-full pt-1">
            <div className="p-2 rounded-2xl bg-white/5 text-center">
              <span className="text-xs font-extrabold text-white block tabular-nums">
                {(streamer.followersCount / 1000).toFixed(1)}k
              </span>
              <span className="text-[10px] text-slate-400">Followers</span>
            </div>
            <div className="p-2 rounded-2xl bg-white/5 text-center">
              <span className="text-xs font-extrabold text-amber-300 block tabular-nums">
                {(streamer.diamondsEarned / 1000).toFixed(1)}k
              </span>
              <span className="text-[10px] text-slate-400">Diamonds</span>
            </div>
            <div className="p-2 rounded-2xl bg-white/5 text-center">
              <span className="text-xs font-extrabold text-pink-400 block tabular-nums">
                {(streamer.likesCount / 1000).toFixed(1)}k
              </span>
              <span className="text-[10px] text-slate-400">Likes</span>
            </div>
          </div>
        </div>

        {/* Bio */}
        <p className="text-xs text-slate-300 bg-white/5 p-3 rounded-2xl border border-white/5 leading-relaxed my-2">
          {streamer.bio}
        </p>

        {/* Feature 1: START VIDEO CALL BUTTON */}
        <div className="space-y-2 pt-2">
          <button
            onClick={handleStartCall}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 hover:opacity-95 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-pink-600/30 active:scale-[0.98] transition-all"
          >
            <PhoneCall className="w-4 h-4 text-amber-300 animate-bounce" />
            <span>Start 1-on-1 Video Call</span>
          </button>

          {/* Secondary Action Grid */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => toggleFollow(streamer.id)}
              className={`py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
                streamer.isFollowing
                  ? 'bg-white/10 text-pink-300'
                  : 'bg-white/5 hover:bg-white/10 text-white'
              }`}
            >
              {streamer.isFollowing ? (
                <>
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Following</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Follow</span>
                </>
              )}
            </button>

            <button
              onClick={handleOpenChat}
              className="py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5 text-purple-400" />
              <span>Message</span>
            </button>

            <button
              onClick={() => setIsGiftModalOpen(true)}
              className="py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Gift className="w-3.5 h-3.5 text-pink-400" />
              <span>Send Gift</span>
            </button>
          </div>

          {streamer.isLive && (
            <button
              onClick={handleWatchLive}
              className="w-full py-2.5 rounded-xl bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/40 text-pink-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Watch Ongoing Live Stream ({streamer.category})</span>
            </button>
          )}
        </div>
      </div>

      {/* Gift Modal */}
      <GiftModal
        isOpen={isGiftModalOpen}
        onClose={() => setIsGiftModalOpen(false)}
        streamerId={streamer.id}
        streamerName={streamer.displayName}
      />
    </div>
  );
};
