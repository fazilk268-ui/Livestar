import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  Users,
  Heart,
  Video,
  PhoneCall,
  UserPlus,
  UserCheck,
  TrendingUp,
  Headphones,
  Gamepad2,
  Mic2,
  Swords,
  RefreshCw,
  Copy,
  Check,
  Shield,
  UserPlus2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Streamer } from '../../types';

export const HomeScreen: React.FC = () => {
  const {
    streamers,
    enterLiveRoom,
    startVideoCall,
    toggleFollow,
    setCurrentScreen,
    openUserProfile,
    refreshUsers,
    isSyncingUsers,
    currentUser,
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = [
    { id: 'All', label: 'All Users', icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'Music', label: 'Music', icon: <Headphones className="w-3.5 h-3.5" /> },
    { id: 'Gaming', label: 'Gaming', icon: <Gamepad2 className="w-3.5 h-3.5" /> },
    { id: 'Chat', label: 'Talk & Chill', icon: <Mic2 className="w-3.5 h-3.5" /> },
    { id: 'PK Battle', label: 'PK Battles', icon: <Swords className="w-3.5 h-3.5" /> },
    { id: 'Following', label: 'Following', icon: <UserCheck className="w-3.5 h-3.5" /> },
  ];

  // Search across ALL registered users in the shared database
  const filteredStreamers = streamers.filter((s) => {
    const matchesCategory =
      selectedCategory === 'All'
        ? true
        : selectedCategory === 'Following'
        ? s.isFollowing
        : s.category === selectedCategory;

    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesCategory;

    const matchesSearch =
      s.displayName.toLowerCase().includes(query) ||
      s.username.toLowerCase().includes(query) ||
      s.id.toLowerCase().includes(query) ||
      (s.title || '').toLowerCase().includes(query) ||
      (s.bio || '').toLowerCase().includes(query) ||
      (s.tags || []).some((t) => t.toLowerCase().includes(query));

    return matchesCategory && matchesSearch;
  });

  const featuredStreamer = streamers[0];

  const handleCopyId = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(id).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  return (
    <div className="pb-24 pt-2 px-3 max-w-lg mx-auto space-y-4">
      {/* Shared Database Status & Multi-Device Sync Banner */}
      <div className="px-3 py-2 rounded-2xl bg-[#12162a]/90 border border-white/10 flex items-center justify-between text-xs backdrop-blur-md">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <div className="flex flex-col">
            <span className="font-bold text-white text-[11px] flex items-center gap-1">
              <span>Shared User Database</span>
              <span className="text-[10px] text-pink-300 font-normal">({streamers.length} registered)</span>
            </span>
            <span className="text-[9px] text-slate-400">Synced across all connected devices</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => refreshUsers()}
            disabled={isSyncingUsers}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors flex items-center gap-1 text-[11px] disabled:opacity-50"
            title="Refresh Users from Shared Database"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingUsers ? 'animate-spin text-pink-400' : ''}`} />
            <span className="hidden sm:inline">Sync</span>
          </button>

          <button
            onClick={() => setCurrentScreen('auth')}
            className="px-2.5 py-1 rounded-xl bg-pink-600/90 hover:bg-pink-500 text-white text-[11px] font-bold flex items-center gap-1 shadow-md shadow-pink-600/20 active:scale-95 transition-all"
            title="Register Another User Account"
          >
            <UserPlus2 className="w-3.5 h-3.5" />
            <span>+ User</span>
          </button>
        </div>
      </div>

      {/* Search Input: Searches all registered users */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search registered users, @handles, unique IDs..."
          className="w-full pl-10 pr-16 py-2.5 bg-white/5 border border-white/10 rounded-2xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500/50 focus:ring-1 focus:ring-pink-500/50 transition-all"
        />
        {searchQuery ? (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
          >
            Clear
          </button>
        ) : (
          <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono">
            {filteredStreamers.length} users
          </span>
        )}
      </div>

      {/* Categories Horizontal Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar scroll-smooth">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/20'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white border border-white/5'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Featured Stream Hero Banner (When no search active and users exist) */}
      {!searchQuery && selectedCategory === 'All' && featuredStreamer && (
        <div className="relative rounded-3xl overflow-hidden border border-pink-500/20 shadow-2xl shadow-pink-900/10 group">
          <div className="h-60 sm:h-64 w-full relative">
            <img
              src={featuredStreamer.coverImage}
              alt={featuredStreamer.displayName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#080911] via-[#080911]/50 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#080911]/80 via-transparent to-transparent" />
          </div>

          {/* Floating Badges */}
          <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pink-600/90 backdrop-blur-md text-white text-xs font-bold tracking-wider shadow-lg animate-pulse">
              <span className="w-2 h-2 rounded-full bg-white" />
              <span>LIVE</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={(e) => handleCopyId(e, featuredStreamer.id)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] text-pink-300 font-mono border border-white/10 hover:bg-black"
                title="Copy User ID"
              >
                <span>ID: {featuredStreamer.id.slice(0, 10)}...</span>
                {copiedId === featuredStreamer.id ? (
                  <Check className="w-3 h-3 text-emerald-400" />
                ) : (
                  <Copy className="w-3 h-3 text-slate-400" />
                )}
              </button>
            </div>
          </div>

          {/* Bottom Info & CTAs */}
          <div className="absolute bottom-3 left-3 right-3 space-y-2">
            <div className="flex items-center gap-2.5">
              <img
                src={featuredStreamer.avatar}
                alt={featuredStreamer.displayName}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full border-2 border-pink-400 object-cover shadow-md"
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-white font-bold text-sm truncate">
                    {featuredStreamer.displayName}
                  </span>
                  <span className="text-[10px] text-pink-300 font-mono">
                    @{featuredStreamer.username}
                  </span>
                </div>
                <p className="text-xs text-slate-300 truncate">{featuredStreamer.title || featuredStreamer.bio}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => enterLiveRoom(featuredStreamer)}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-pink-500/30 active:scale-[0.98] transition-all"
              >
                <Video className="w-4 h-4" />
                <span>Watch Stream</span>
              </button>

              <button
                onClick={() => startVideoCall(featuredStreamer)}
                className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-semibold text-xs flex items-center justify-center gap-1.5 backdrop-blur-md active:scale-[0.98] transition-all"
              >
                <PhoneCall className="w-4 h-4 text-purple-400" />
                <span>1v1 Video Call</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Section Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2">
          <h2 className="font-display font-bold text-base text-white tracking-tight">
            {searchQuery ? `Search Results` : selectedCategory === 'All' ? 'Registered Users' : `${selectedCategory}`}
          </h2>
          <span className="text-xs text-slate-400 font-mono">({filteredStreamers.length})</span>
        </div>
        <button
          onClick={() => setCurrentScreen('wallet')}
          className="text-xs font-semibold text-pink-400 hover:text-pink-300"
        >
          Daily Coins →
        </button>
      </div>

      {/* Registered Users Grid */}
      {filteredStreamers.length > 0 ? (
        <div className="grid grid-cols-2 gap-3">
          {filteredStreamers.map((user) => (
            <div
              key={user.id}
              className="group relative rounded-2xl overflow-hidden bg-[#121626]/70 border border-white/10 hover:border-pink-500/40 transition-all flex flex-col cursor-pointer"
              onClick={() => enterLiveRoom(user)}
            >
              {/* Cover Image & Overlays */}
              <div className="relative aspect-[4/5] w-full overflow-hidden bg-slate-900">
                <img
                  src={user.coverImage}
                  alt={user.displayName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                {/* Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0f1a] via-black/20 to-black/40" />

                {/* Top Badges */}
                <div className="absolute top-2 left-2 right-2 flex items-center justify-between">
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-pink-600/90 backdrop-blur-md text-[10px] font-bold text-white shadow">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    <span>ONLINE</span>
                  </div>

                  {/* Copy Unique User ID button */}
                  <button
                    onClick={(e) => handleCopyId(e, user.id)}
                    className="flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-black/75 backdrop-blur-md text-[9px] font-mono text-purple-300 border border-white/10 hover:bg-black"
                    title={`Unique ID: ${user.id} (Click to copy)`}
                  >
                    <span>{user.id.slice(0, 8)}</span>
                    {copiedId === user.id ? (
                      <Check className="w-2.5 h-2.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-2.5 h-2.5 text-slate-400" />
                    )}
                  </button>
                </div>

                {/* Category Pill */}
                <div className="absolute bottom-2 left-2">
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-black/60 text-slate-200 backdrop-blur-md border border-white/10">
                    {user.category || 'Creator'}
                  </span>
                </div>

                {/* Quick 1v1 Video Call Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startVideoCall(user);
                  }}
                  title={`Start 1-on-1 Call with ${user.displayName}`}
                  className="absolute bottom-2 right-2 w-8 h-8 rounded-full bg-purple-600/90 hover:bg-purple-500 text-white flex items-center justify-center shadow-lg backdrop-blur-md hover:scale-110 active:scale-95 transition-all"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
                </button>
              </div>

              {/* Detail Strip */}
              <div className="p-2.5 flex flex-col justify-between flex-1 space-y-1.5">
                <div className="flex items-start justify-between gap-1">
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      openUserProfile(user);
                    }}
                    className="flex items-center gap-1.5 min-w-0 cursor-pointer hover:text-pink-300 transition-colors"
                  >
                    <img
                      src={user.avatar}
                      alt={user.displayName}
                      referrerPolicy="no-referrer"
                      className="w-6 h-6 rounded-full object-cover border border-pink-400/60 shrink-0 hover:scale-110 transition-transform"
                    />
                    <div className="min-w-0">
                      <span className="text-xs font-bold text-white truncate block hover:underline">
                        {user.displayName}
                      </span>
                      <span className="text-[9px] text-slate-400 font-mono truncate block">
                        @{user.username}
                      </span>
                    </div>
                  </div>

                  {/* Follow Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFollow(user.id);
                    }}
                    className={`p-1 rounded-lg text-[10px] font-semibold transition-colors ${
                      user.isFollowing
                        ? 'text-pink-400 hover:text-pink-300'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {user.isFollowing ? (
                      <UserCheck className="w-4 h-4 text-pink-400" />
                    ) : (
                      <UserPlus className="w-4 h-4 text-slate-300 hover:text-pink-400" />
                    )}
                  </button>
                </div>

                <p className="text-[11px] text-slate-300 line-clamp-1 leading-tight">
                  {user.bio || user.title || 'LiveStar Community Member'}
                </p>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5 border-t border-white/5">
                  <div className="flex items-center gap-1 font-mono text-[9px] text-purple-300">
                    <Shield className="w-2.5 h-2.5 text-emerald-400" />
                    <span>ID: {user.id.slice(0, 7)}...</span>
                  </div>
                  <span className="text-pink-400 font-medium">Connect →</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-16 text-center space-y-3 bg-white/5 rounded-3xl p-6 border border-white/5">
          <div className="w-12 h-12 rounded-full bg-pink-500/10 text-pink-400 flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-white">
            {searchQuery ? `No users matching "${searchQuery}"` : 'No registered users in this category'}
          </h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            {searchQuery
              ? 'Try searching by full name, handle (@username), or unique ID.'
              : 'Register a new user account to start broadcasting and calling!'}
          </p>
          <div className="flex items-center justify-center gap-2 pt-1">
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 rounded-xl bg-white/10 text-white text-xs font-semibold hover:bg-white/15 transition-colors"
              >
                Reset Search
              </button>
            )}
            <button
              onClick={() => setCurrentScreen('auth')}
              className="px-4 py-2 rounded-xl bg-pink-600 text-white text-xs font-semibold hover:bg-pink-500 transition-colors"
            >
              Register New User
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
