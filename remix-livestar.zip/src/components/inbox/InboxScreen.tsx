import React, { useState } from 'react';
import {
  MessageCircle,
  Bell,
  CheckCheck,
  Send,
  ArrowLeft,
  Video,
  Radio,
  Flame,
  UserCheck,
  Sparkles,
  PhoneCall,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { NotificationItem, MessageThread } from '../../types';

export const InboxScreen: React.FC = () => {
  const {
    notifications,
    messageThreads,
    activeThreadId,
    setActiveThreadId,
    sendMessageToThread,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    enterLiveRoom,
    streamers,
    setCurrentScreen,
    startVideoCall,
    openUserProfile,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'messages' | 'notifications'>('messages');
  const [replyText, setReplyText] = useState<string>('');

  const activeThread = messageThreads.find((t) => t.id === activeThreadId);

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeThreadId) return;

    sendMessageToThread(activeThreadId, replyText.trim());
    setReplyText('');
  };

  const handleNotificationClick = (notif: NotificationItem) => {
    markNotificationAsRead(notif.id);
    if (notif.actionScreen === 'live_room' && notif.streamerId) {
      const streamer = streamers.find((s) => s.id === notif.streamerId);
      if (streamer) enterLiveRoom(streamer);
    } else if (notif.actionScreen === 'wallet') {
      setCurrentScreen('wallet');
    } else if (notif.actionScreen === 'profile') {
      setCurrentScreen('profile');
    }
  };

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'live':
        return <Radio className="w-4 h-4 text-pink-400" />;
      case 'gift':
        return <Flame className="w-4 h-4 text-amber-400" />;
      case 'follow':
        return <UserCheck className="w-4 h-4 text-purple-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-blue-400" />;
    }
  };

  // If viewing a single direct chat thread
  if (activeThread) {
    const streamer = streamers.find((s) => s.id === activeThread.streamerId);

    return (
      <div className="h-screen max-w-lg mx-auto flex flex-col justify-between bg-[#080911] select-none">
        {/* Thread Header */}
        <div className="sticky top-0 z-30 p-3 bg-[#0d0f1c]/95 backdrop-blur-md border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setActiveThreadId(null)}
              className="p-1.5 rounded-full hover:bg-white/10 text-slate-300"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="relative">
              <img
                src={activeThread.streamerAvatar}
                alt={activeThread.streamerName}
                referrerPolicy="no-referrer"
                className="w-9 h-9 rounded-full object-cover border border-pink-400"
              />
              {activeThread.isOnline && (
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#080911]" />
              )}
            </div>
            <div
              onClick={() => streamer && openUserProfile(streamer)}
              className="cursor-pointer"
            >
              <h3 className="text-xs font-bold text-white hover:text-pink-300 transition-colors">
                {activeThread.streamerName}
              </h3>
              <span className="text-[10px] text-emerald-400">
                {activeThread.isOnline ? 'Online now' : 'Active today'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {streamer && (
              <>
                <button
                  onClick={() => startVideoCall(streamer)}
                  className="px-2.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-bold flex items-center gap-1 shadow-md shadow-purple-600/20 active:scale-95 transition-transform"
                  title="Start 1-on-1 Video Call"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
                  <span>Call</span>
                </button>

                <button
                  onClick={() => enterLiveRoom(streamer)}
                  className="px-2.5 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-[11px] font-bold flex items-center gap-1 shadow-md shadow-pink-500/20 active:scale-95 transition-transform"
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Live</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="text-center my-2">
            <span className="text-[10px] text-slate-500 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
              Messages are end-to-end encrypted on LiveStar
            </span>
          </div>

          {activeThread.messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[78%] px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed ${
                  msg.isMe
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-br-xs'
                    : 'bg-[#181c30] text-slate-200 border border-white/10 rounded-bl-xs'
                }`}
              >
                {msg.text}
              </div>
              <span className="text-[9px] text-slate-500 mt-0.5 px-1">{msg.timestamp}</span>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <form
          onSubmit={handleSendReply}
          className="p-3 bg-[#0d0f1c] border-t border-white/10 flex items-center gap-2"
        >
          <input
            type="text"
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder={`Message ${activeThread.streamerName}...`}
            className="flex-1 px-4 py-2.5 rounded-full bg-white/5 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500"
          />
          <button
            type="submit"
            disabled={!replyText.trim()}
            className="w-9 h-9 rounded-full bg-pink-500 hover:bg-pink-400 text-white flex items-center justify-center disabled:opacity-40 transition-colors shadow-md shadow-pink-500/30"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="pb-24 pt-2 px-3 max-w-lg mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="font-display font-bold text-lg text-white">Inbox & Activity</h1>
        {activeTab === 'notifications' && (
          <button
            onClick={markAllNotificationsAsRead}
            className="text-xs font-semibold text-pink-400 hover:text-pink-300 flex items-center gap-1"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>Mark all read</span>
          </button>
        )}
      </div>

      {/* Segmented Tabs */}
      <div className="flex items-center p-1 bg-white/5 rounded-2xl border border-white/5">
        <button
          onClick={() => setActiveTab('messages')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'messages'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <MessageCircle className="w-3.5 h-3.5" />
          <span>Messages</span>
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'notifications'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Alerts</span>
        </button>
      </div>

      {/* MESSAGES TAB */}
      {activeTab === 'messages' && (
        <div className="space-y-2">
          {messageThreads.map((thread) => (
            <div
              key={thread.id}
              onClick={() => setActiveThreadId(thread.id)}
              className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 flex items-center justify-between gap-3 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative shrink-0">
                  <img
                    src={thread.streamerAvatar}
                    alt={thread.streamerName}
                    referrerPolicy="no-referrer"
                    className="w-11 h-11 rounded-full object-cover border border-pink-400/50"
                  />
                  {thread.isOnline && (
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#080911]" />
                  )}
                </div>

                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-white truncate">{thread.streamerName}</h4>
                  <p className="text-[11px] text-slate-300 truncate mt-0.5">{thread.lastMessage}</p>
                </div>
              </div>

              <div className="text-right shrink-0 flex flex-col items-end gap-1">
                <span className="text-[10px] text-slate-500">{thread.lastTimestamp}</span>
                {thread.unreadCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-pink-500 text-white text-[10px] font-bold">
                    {thread.unreadCount}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* NOTIFICATIONS TAB */}
      {activeTab === 'notifications' && (
        <div className="space-y-2">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif)}
              className={`p-3 rounded-2xl border transition-all flex items-start gap-3 cursor-pointer ${
                notif.isRead
                  ? 'bg-white/5 border-white/5 hover:bg-white/10'
                  : 'bg-gradient-to-r from-pink-900/20 via-purple-900/20 to-transparent border-pink-500/30'
              }`}
            >
              <div className="relative shrink-0">
                <img
                  src={notif.avatar}
                  alt={notif.title}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover border border-white/10"
                />
                <div className="absolute -bottom-1 -right-1 p-0.5 rounded-full bg-[#080911]">
                  {getNotificationIcon(notif.type)}
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h4 className="text-xs font-bold text-white truncate">{notif.title}</h4>
                  <span className="text-[10px] text-slate-500 shrink-0">{notif.timestamp}</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-snug mt-0.5">{notif.message}</p>
              </div>

              {!notif.isRead && (
                <span className="w-2 h-2 rounded-full bg-pink-500 shrink-0 mt-2" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
