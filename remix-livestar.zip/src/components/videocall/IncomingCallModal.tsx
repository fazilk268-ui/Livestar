import React, { useEffect, useState } from 'react';
import { Phone, PhoneOff, Video, Sparkles, Shield, Volume2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const IncomingCallModal: React.FC = () => {
  const { isIncomingCall, incomingCaller, acceptIncomingCall, rejectIncomingCall } = useApp();
  const [ringTime, setRingTime] = useState<number>(0);

  // Ring timer simulation
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isIncomingCall) {
      setRingTime(0);
      interval = setInterval(() => {
        setRingTime((prev) => {
          // If no answer after 30 seconds, auto-decline
          if (prev >= 28) {
            rejectIncomingCall();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isIncomingCall, rejectIncomingCall]);

  if (!isIncomingCall || !incomingCaller) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-300 select-none">
      <div className="relative w-full max-w-sm rounded-[40px] bg-gradient-to-b from-[#161a2e] via-[#0f1222] to-[#080911] border border-pink-500/30 p-6 flex flex-col items-center justify-between min-h-[520px] shadow-2xl shadow-pink-900/30 overflow-hidden text-center">
        {/* Background Ambient Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-pink-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Tag */}
        <div className="relative z-10 space-y-1.5 pt-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-500/20 border border-pink-500/30 text-pink-300 text-xs font-bold animate-pulse">
            <Video className="w-3.5 h-3.5 text-pink-400" />
            <span>INCOMING 1-ON-1 VIDEO CALL</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
            <Volume2 className="w-3.5 h-3.5 text-purple-400 animate-bounce" />
            <span>Ringing... ({30 - ringTime}s remaining)</span>
          </div>
        </div>

        {/* Caller Avatar with Pulsing Rings */}
        <div className="relative z-10 my-6 flex flex-col items-center">
          {/* Animated concentric pulse rings */}
          <div className="relative flex items-center justify-center">
            <div className="absolute w-36 h-36 rounded-full border-2 border-pink-500/30 animate-ping opacity-60 pointer-events-none" />
            <div className="absolute w-44 h-44 rounded-full border border-purple-500/20 animate-pulse pointer-events-none" />

            <div className="w-28 h-28 rounded-full p-1 bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-600 shadow-2xl shadow-pink-500/40">
              <img
                src={incomingCaller.avatar}
                alt={incomingCaller.displayName}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover"
              />
            </div>
          </div>

          {/* Caller Details */}
          <div className="mt-4 space-y-1">
            <h2 className="text-xl font-display font-extrabold text-white tracking-tight">
              {incomingCaller.displayName}
            </h2>
            <p className="text-xs text-pink-300 font-semibold">@{incomingCaller.username}</p>
            <p className="text-[11px] text-slate-400 max-w-[240px] truncate">
              {incomingCaller.title || 'Creator on LiveStar'}
            </p>
          </div>
        </div>

        {/* Call Security & Agora Notice */}
        <div className="relative z-10 w-full px-3 py-2 rounded-2xl bg-white/5 border border-white/5 text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
          <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>Agora RTC Channel · App ID: c4a9cf6f9245456b929b79923f713952</span>
        </div>

        {/* Action Controls: Reject & Accept */}
        <div className="relative z-10 w-full pt-4 flex items-center justify-around gap-6">
          {/* Reject Call Button */}
          <div className="flex flex-col items-center gap-1.5">
            <button
              onClick={rejectIncomingCall}
              className="w-16 h-16 rounded-full bg-gradient-to-tr from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white flex items-center justify-center shadow-xl shadow-red-600/40 active:scale-95 transition-transform"
              title="Decline Call"
            >
              <PhoneOff className="w-7 h-7" />
            </button>
            <span className="text-xs font-bold text-slate-300">Decline</span>
          </div>

          {/* Accept Call Button */}
          <div className="flex flex-col items-center gap-1.5">
            <button
              onClick={acceptIncomingCall}
              className="w-16 h-16 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white flex items-center justify-center shadow-xl shadow-emerald-500/40 active:scale-95 transition-transform animate-bounce"
              title="Accept Video Call"
            >
              <Phone className="w-7 h-7" />
            </button>
            <span className="text-xs font-bold text-emerald-400">Accept</span>
          </div>
        </div>
      </div>
    </div>
  );
};
