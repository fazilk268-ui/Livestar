import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  SwitchCamera,
  Heart,
  Flame,
  Sparkles,
  Shield,
  Clock,
  Gift,
  Info,
  Zap,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  Users,
  Radio,
  Share2,
  Settings,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GiftModal } from '../live/GiftModal';
import { agoraCallManager, AgoraCallState } from '../../services/agoraService';
import { AGORA_CONFIG } from '../../config/agoraConfig';

export const VideoCallScreen: React.FC = () => {
  const { activeStreamer, endVideoCall, callDuration, currentUser } = useApp();

  const [callState, setCallState] = useState<AgoraCallState>(agoraCallManager.getState());
  const [showAgoraInfo, setShowAgoraInfo] = useState<boolean>(false);
  const [showRoomModal, setShowRoomModal] = useState<boolean>(false);
  const [customRoomInput, setCustomRoomInput] = useState<string>('');
  const [reactions, setReactions] = useState<{ id: number; emoji: string; x: number }[]>([]);
  const [isGiftModalOpen, setIsGiftModalOpen] = useState<boolean>(false);
  const [statusToast, setStatusToast] = useState<string | null>(null);
  const [appCertInput, setAppCertInput] = useState<string>('');
  const [certUpdateStatus, setCertUpdateStatus] = useState<string | null>(null);

  const localContainerRef = useRef<HTMLDivElement>(null);
  const remoteContainerRef = useRef<HTMLDivElement>(null);
  const prevRemoteJoinedRef = useRef<boolean>(false);

  // Subscribe to Agora call manager updates
  useEffect(() => {
    const unsubscribe = agoraCallManager.subscribe((newState) => {
      setCallState(newState);

      // Detect remote user join/leave transitions for user feedback
      if (!prevRemoteJoinedRef.current && newState.remoteUserJoined) {
        showToast(`${activeStreamer?.displayName || 'Remote user'} joined the call`);
      } else if (prevRemoteJoinedRef.current && !newState.remoteUserJoined) {
        showToast(`${activeStreamer?.displayName || 'Remote user'} left the call`);
      }
      prevRemoteJoinedRef.current = newState.remoteUserJoined;
    });
    return () => unsubscribe();
  }, [activeStreamer]);

  // Start Agora call on mount or streamer change
  useEffect(() => {
    if (!activeStreamer) return;

    // Check if a specific room was requested via URL query string
    const searchParams = new URLSearchParams(window.location.search);
    const urlRoom = searchParams.get('room') || searchParams.get('channel') || undefined;

    const callerId = currentUser?.id || 'usr_local';
    const receiverId = activeStreamer.id;

    agoraCallManager.startCall(callerId, receiverId, urlRoom).then((success) => {
      if (success) {
        if (localContainerRef.current) {
          agoraCallManager.playLocalVideo(localContainerRef.current);
        }
      }
    });

    return () => {
      agoraCallManager.endCall();
    };
  }, [activeStreamer, currentUser]);

  // Ensure local video track is played into localContainerRef whenever track or element is available
  useEffect(() => {
    if (localContainerRef.current && callState.isVideoEnabled && callState.isJoined) {
      agoraCallManager.playLocalVideo(localContainerRef.current);
    }
  }, [callState.isVideoEnabled, callState.isJoined]);

  // Ensure remote video track is played into remoteContainerRef whenever remoteVideoActive changes
  useEffect(() => {
    if (remoteContainerRef.current && callState.remoteVideoActive) {
      agoraCallManager.playRemoteVideo(remoteContainerRef.current);
    }
  }, [callState.remoteVideoActive]);

  if (!activeStreamer) {
    return (
      <div className="h-screen flex items-center justify-center p-4 bg-[#080911]">
        <button
          onClick={endVideoCall}
          className="px-4 py-2 rounded-xl bg-pink-600 text-white text-sm"
        >
          Return Home
        </button>
      </div>
    );
  }

  // Format call duration MM:SS
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  const showToast = (text: string) => {
    setStatusToast(text);
    setTimeout(() => setStatusToast(null), 2500);
  };

  const handleToggleMic = async () => {
    const isMuted = await agoraCallManager.toggleMicrophone();
    showToast(isMuted ? 'Microphone Muted' : 'Microphone Active');
  };

  const handleToggleVideo = async () => {
    const isEnabled = await agoraCallManager.toggleCamera();
    showToast(isEnabled ? 'Camera Enabled' : 'Camera Disabled');
    if (isEnabled && localContainerRef.current) {
      setTimeout(() => {
        agoraCallManager.playLocalVideo(localContainerRef.current);
      }, 100);
    }
  };

  const handleSwitchCamera = async () => {
    if (localContainerRef.current) {
      const mode = await agoraCallManager.switchCameraFacing(localContainerRef.current);
      showToast(mode === 'user' ? 'Front Camera Active' : 'Rear Camera Active');
    }
  };

  const handleHangup = async () => {
    await agoraCallManager.endCall();
    endVideoCall();
  };

  const copyCallLink = () => {
    const callUrl = `${window.location.origin}${window.location.pathname}?room=${callState.channelName}`;
    navigator.clipboard.writeText(callUrl).then(
      () => showToast('Call Link Copied! Open in 2nd tab to test'),
      () => showToast(`Room Code: ${callState.channelName}`)
    );
  };

  const copyChannelName = () => {
    navigator.clipboard.writeText(callState.channelName).then(
      () => showToast(`Channel Name Copied: ${callState.channelName}`),
      () => showToast(`Channel: ${callState.channelName}`)
    );
  };

  const handleSwitchCustomRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customRoomInput.trim()) return;

    const newRoom = customRoomInput.trim();
    setShowRoomModal(false);
    showToast(`Switching to room: ${newRoom}...`);

    await agoraCallManager.endCall();
    const callerId = currentUser?.id || 'usr_local';
    await agoraCallManager.startCall(callerId, undefined, newRoom);
    if (localContainerRef.current) {
      agoraCallManager.playLocalVideo(localContainerRef.current);
    }
  };

  const handleSaveAppCert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!appCertInput.trim()) return;

    try {
      setCertUpdateStatus('Saving certificate to server...');
      const res = await fetch('/api/agora/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appCertificate: appCertInput.trim() }),
      });
      const data = await res.json();
      if (res.ok) {
        setCertUpdateStatus('Certificate configured on backend!');
        showToast('App Certificate configured! Tokens enabled.');
        setAppCertInput('');
      } else {
        setCertUpdateStatus(`Error: ${data.error || 'Failed to update'}`);
      }
    } catch (err: any) {
      setCertUpdateStatus(`Network error: ${err.message}`);
    }
  };

  const spawnReaction = (emoji: string) => {
    const reaction = {
      id: Date.now() + Math.random(),
      emoji,
      x: Math.random() * 60 + 20,
    };
    setReactions((prev) => [...prev, reaction]);
    setTimeout(() => {
      setReactions((prev) => prev.filter((r) => r.id !== reaction.id));
    }, 2000);
  };

  return (
    <div className="relative h-screen w-full bg-[#080911] overflow-hidden flex flex-col justify-between select-none">
      {/* ======================================================== */}
      {/* 1. MAIN REMOTE VIDEO AREA (Real Agora Remote Stream) */}
      {/* ======================================================== */}
      <div className="absolute inset-0 z-0 bg-[#06070e] overflow-hidden flex items-center justify-center">
        {/* Real Agora Remote Video Stream Player Element */}
        <div
          id="agora-remote-player"
          ref={remoteContainerRef}
          className={`absolute inset-0 w-full h-full object-cover z-10 transition-opacity duration-300 ${
            callState.remoteVideoActive ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'
          }`}
        />

        {/* Remote Active Stream Overlay Badge (When remote video is displaying) */}
        {callState.remoteVideoActive && (
          <div className="absolute bottom-28 left-4 z-20 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white text-xs shadow-lg animate-in fade-in">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-slate-200">{activeStreamer.displayName}</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-pink-500/20 text-pink-300 border border-pink-500/30">
              Live HD
            </span>
          </div>
        )}

        {/* Remote User In Room But Camera Off */}
        {callState.remoteUserJoined && !callState.remoteVideoActive && (
          <div className="relative z-10 flex flex-col items-center justify-center text-center p-6 space-y-4 max-w-xs animate-in fade-in">
            <div className="relative">
              <img
                src={activeStreamer.avatar}
                alt={activeStreamer.displayName}
                referrerPolicy="no-referrer"
                className="w-28 h-28 rounded-full object-cover border-4 border-pink-500/50 shadow-2xl"
              />
              <span className="absolute bottom-1 right-1 p-2 rounded-full bg-slate-900 border border-white/20 text-slate-400">
                <VideoOff className="w-5 h-5 text-rose-400" />
              </span>
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">{activeStreamer.displayName}</h3>
              <p className="text-xs text-pink-300">Connected to Agora Call</p>
              <p className="text-[11px] text-slate-400">Camera is currently disabled by participant</p>
            </div>
            {callState.remoteAudioActive && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs">
                <Mic className="w-3.5 h-3.5 animate-pulse" />
                <span>Microphone Active</span>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* WAITING SCREEN: When other user has not joined yet */}
        {/* Real Agora RTC session waiting for 2nd participant */}
        {/* ======================================================== */}
        {!callState.remoteUserJoined && (
          <div className="relative z-10 flex flex-col items-center justify-center text-center p-6 space-y-5 max-w-sm animate-in fade-in">
            {/* Animated Radar Pulse Rings */}
            <div className="relative flex items-center justify-center">
              <div className="absolute w-44 h-44 rounded-full border-2 border-pink-500/25 animate-ping opacity-75 pointer-events-none" />
              <div className="absolute w-56 h-56 rounded-full border border-purple-500/20 animate-pulse pointer-events-none" />

              <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-600 shadow-2xl shadow-pink-500/30">
                <img
                  src={activeStreamer.avatar}
                  alt={activeStreamer.displayName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-500/15 border border-pink-500/30 text-pink-300 text-xs font-bold">
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-ping" />
                <span>WAITING FOR PARTICIPANT</span>
              </div>
              <h2 className="text-lg font-extrabold text-white">
                Calling {activeStreamer.displayName}...
              </h2>
              <p className="text-xs text-slate-400">
                Waiting for the other user to join this Agora video channel.
              </p>
            </div>

            {/* Channel Info & 2-Tab Testing Helper */}
            <div className="w-full p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md text-left space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Agora Channel:</span>
                <button
                  onClick={copyChannelName}
                  className="font-mono text-pink-300 hover:text-pink-200 text-[11px] flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded border border-white/5"
                  title="Copy Channel Name"
                >
                  <span className="truncate max-w-[140px]">{callState.channelName}</span>
                  <Copy className="w-3 h-3 shrink-0 text-slate-400" />
                </button>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={copyCallLink}
                  className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Copy Call Link</span>
                </button>

                <button
                  onClick={() => setShowRoomModal(true)}
                  className="py-2 px-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  title="Switch or enter a custom Room Code"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Room</span>
                </button>
              </div>

              <p className="text-[10px] text-slate-400 leading-relaxed text-center">
                Tip: Paste link into another browser tab or phone to test 2-way Agora video!
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Floating Reactions */}
      <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden">
        {reactions.map((r) => (
          <div
            key={r.id}
            className="absolute bottom-40 animate-float-heart text-3xl filter drop-shadow-md"
            style={{ left: `${r.x}%` }}
          >
            {r.emoji}
          </div>
        ))}
      </div>

      {/* Status Feedback Toast */}
      {statusToast && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 text-white text-xs font-bold backdrop-blur-md shadow-2xl animate-in fade-in">
          {statusToast}
        </div>
      )}

      {/* ======================================================== */}
      {/* TOP BAR: CALL STATUS, TIMER & AGORA BADGE */}
      {/* ======================================================== */}
      <div className="relative z-20 pt-4 px-4 flex items-center justify-between">
        {/* Streamer Profile Pill */}
        <div className="flex items-center gap-2 p-1.5 pl-2 pr-3 rounded-full bg-black/60 backdrop-blur-xl border border-white/10">
          <img
            src={activeStreamer.avatar}
            alt={activeStreamer.displayName}
            referrerPolicy="no-referrer"
            className="w-8 h-8 rounded-full object-cover border border-pink-400"
          />
          <div className="flex flex-col">
            <span className="text-xs font-bold text-white truncate max-w-[110px]">
              {activeStreamer.displayName}
            </span>
            <div className="flex items-center gap-1 text-[10px]">
              {callState.remoteUserJoined ? (
                <span className="text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Connected</span>
                </span>
              ) : (
                <span className="text-amber-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                  <span>Connecting...</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right Info & Duration */}
        <div className="flex items-center gap-2">
          {/* Agora Status Badge & Config Modal Trigger */}
          <button
            onClick={() => setShowAgoraInfo((prev) => !prev)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/30 text-purple-200 text-[10px] font-bold backdrop-blur-md transition-colors"
            title="Agora RTC Status & Details"
          >
            <Zap className="w-3 h-3 text-amber-300" />
            <span>Agora RTC</span>
          </button>

          {/* Call Duration Timer */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-xl border border-white/10 text-slate-200 text-xs font-mono font-bold">
            <Clock className="w-3.5 h-3.5 text-pink-400" />
            <span className="tabular-nums">{formatTime(callDuration)}</span>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* AGORA CONFIG & TOKEN SERVER DETAILS MODAL */}
      {/* ======================================================== */}
      {showAgoraInfo && (
        <div className="relative z-30 mx-4 my-1 p-4 rounded-3xl bg-[#0f1224]/95 border border-purple-500/40 backdrop-blur-2xl text-xs space-y-3 shadow-2xl animate-in fade-in max-h-[70vh] overflow-y-auto no-scrollbar">
          <div className="flex items-center justify-between pb-1 border-b border-white/10">
            <span className="font-bold text-white flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>Agora RTC Engine Status</span>
            </span>
            <button
              onClick={() => setShowAgoraInfo(false)}
              className="text-xs text-slate-400 hover:text-white px-2 py-0.5"
            >
              Close
            </button>
          </div>

          <div className="space-y-1.5 text-[11px] text-slate-300">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">App ID:</span>
              <span className="font-mono text-purple-300 text-[10px] bg-black/40 px-2 py-0.5 rounded">
                {AGORA_CONFIG.appId}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Channel Name:</span>
              <span className="font-mono text-pink-300 text-[10px] bg-black/40 px-2 py-0.5 rounded">
                {callState.channelName || 'Not joined'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Local UID:</span>
              <span className="font-mono text-emerald-400 text-[10px]">
                {callState.uid || 'Pending'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Remote Participant:</span>
              <span className="font-semibold text-white text-[10px]">
                {callState.remoteUserJoined ? `UID ${callState.remoteUid} (Joined)` : 'Waiting to join'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Remote Video Stream:</span>
              <span
                className={`font-semibold text-[10px] ${
                  callState.remoteVideoActive ? 'text-emerald-400' : 'text-slate-400'
                }`}
              >
                {callState.remoteVideoActive ? 'Active (Subscribed & Playing)' : 'Inactive'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Token Endpoint:</span>
              <span className="text-emerald-400 font-mono text-[10px]">POST /api/agora/token</span>
            </div>
          </div>

          {/* Android Testing Guide */}
          <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-500/20 text-[11px] text-slate-300 space-y-1.5">
            <h4 className="font-bold text-purple-300 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              <span>Android Testing Instructions</span>
            </h4>
            <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[10px]">
              <li>Open LiveStar URL in Chrome / Brave on your Android mobile device.</li>
              <li>Grant Camera & Microphone access when prompted by the browser.</li>
              <li>Click Start Video Call or open the shared link to join the Agora room.</li>
              <li>For native Android app: configure Agora RTC SDK in Gradle and AndroidManifest permissions.</li>
            </ol>
          </div>

          {/* App Certificate Config Section */}
          <form onSubmit={handleSaveAppCert} className="pt-1 space-y-2 border-t border-white/10">
            <label className="block text-[11px] text-slate-300 font-semibold">
              Agora App Certificate (Backend Token Signing):
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={appCertInput}
                onChange={(e) => setAppCertInput(e.target.value)}
                placeholder="Optional AGORA_APP_CERTIFICATE"
                className="flex-1 px-3 py-1.5 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shrink-0 transition-colors"
              >
                Save
              </button>
            </div>
            {certUpdateStatus && (
              <p className="text-[10px] text-pink-300">{certUpdateStatus}</p>
            )}
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* CUSTOM ROOM MODAL (For easy 2-device / multi-tab pairing) */}
      {/* ======================================================== */}
      {showRoomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-xs p-5 rounded-3xl bg-[#12162a] border border-white/15 text-left space-y-3.5 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Join Specific Room</h3>
              <button
                onClick={() => setShowRoomModal(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enter any custom room name. Both devices or tabs that enter this name will connect to the exact same Agora video call.
            </p>
            <form onSubmit={handleSwitchCustomRoom} className="space-y-3">
              <input
                type="text"
                value={customRoomInput}
                onChange={(e) => setCustomRoomInput(e.target.value)}
                placeholder="e.g. test_room_123"
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-pink-500"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowRoomModal(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold shadow-lg shadow-pink-600/30"
                >
                  Join Room
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* PICTURE-IN-PICTURE (PIP) LOCAL CAMERA STREAM */}
      {/* ======================================================== */}
      <div className="absolute top-20 right-4 z-20 w-28 h-40 sm:w-32 sm:h-44 rounded-2xl overflow-hidden border-2 border-pink-500/70 shadow-2xl bg-[#121626] backdrop-blur-md">
        {/* Real Agora Local Video Stream Player */}
        <div
          id="agora-local-player"
          ref={localContainerRef}
          className={`w-full h-full object-cover ${callState.isVideoEnabled ? 'block' : 'hidden'}`}
        />

        {/* Camera Off Placeholder */}
        {!callState.isVideoEnabled && (
          <div className="w-full h-full flex flex-col items-center justify-center p-2 text-center bg-slate-900 text-slate-400">
            <VideoOff className="w-6 h-6 text-slate-500 mb-1" />
            <span className="text-[10px]">Camera Off</span>
          </div>
        )}

        {/* PIP Overlay Label */}
        <div className="absolute bottom-1 left-2 pointer-events-none z-10">
          <span className="text-[9px] text-white font-bold drop-shadow-md">You</span>
        </div>

        {/* Self PIP Camera Flip Button */}
        <button
          onClick={handleSwitchCamera}
          className="absolute bottom-1.5 right-1.5 z-10 w-6 h-6 rounded-full bg-black/75 hover:bg-black text-white flex items-center justify-center shadow-md active:scale-90 transition-transform"
          title="Switch Camera (Front/Rear)"
        >
          <SwitchCamera className="w-3 h-3 text-pink-300" />
        </button>
      </div>

      {/* QUICK FLOATING CALL REACTIONS & GIFT SHORTCUT */}
      <div className="relative z-20 px-4 flex items-center justify-center gap-2 mb-2">
        {['🔥', '💖', '👏', '🎉', '👑'].map((emoji) => (
          <button
            key={emoji}
            onClick={() => spawnReaction(emoji)}
            className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/10 text-lg flex items-center justify-center hover:scale-115 active:scale-95 transition-all shadow-md"
          >
            {emoji}
          </button>
        ))}

        {/* Send gift in video call */}
        <button
          onClick={() => setIsGiftModalOpen(true)}
          className="px-3 py-1.5 rounded-full bg-gradient-to-r from-pink-500 to-rose-600 text-white text-xs font-bold flex items-center gap-1 shadow-lg shadow-pink-500/20 active:scale-95 transition-transform"
        >
          <Gift className="w-3.5 h-3.5" />
          <span>Gift</span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* BOTTOM CALL CONTROLS */}
      {/* ======================================================== */}
      <div className="relative z-20 pb-8 px-6 max-w-lg mx-auto w-full">
        <div className="p-3.5 rounded-3xl bg-[#0f1220]/95 backdrop-blur-2xl border border-white/15 shadow-2xl flex items-center justify-around gap-2">
          {/* 1. Mute Microphone Toggle */}
          <button
            onClick={handleToggleMic}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
              callState.isAudioMuted
                ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
            title={callState.isAudioMuted ? 'Unmute Microphone' : 'Mute Microphone'}
          >
            {callState.isAudioMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* 2. Toggle Camera Video On/Off */}
          <button
            onClick={handleToggleVideo}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
              !callState.isVideoEnabled
                ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
            title={callState.isVideoEnabled ? 'Turn Camera Off' : 'Turn Camera On'}
          >
            {!callState.isVideoEnabled ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
          </button>

          {/* 3. Camera Switch / Flip Button */}
          <button
            onClick={handleSwitchCamera}
            className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center active:scale-95 transition-all"
            title="Switch Front/Rear Camera"
          >
            <SwitchCamera className="w-5 h-5 text-purple-300" />
          </button>

          {/* 4. End Call Button (Big Red) */}
          <button
            onClick={handleHangup}
            className="w-14 h-14 rounded-full bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white flex items-center justify-center shadow-xl shadow-red-600/40 active:scale-95 transition-transform"
            title="End Call"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Gift Modal in Call */}
      <GiftModal
        isOpen={isGiftModalOpen}
        onClose={() => setIsGiftModalOpen(false)}
        streamerId={activeStreamer.id}
        streamerName={activeStreamer.displayName}
      />
    </div>
  );
};
