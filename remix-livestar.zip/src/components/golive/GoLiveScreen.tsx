import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Radio,
  SwitchCamera,
  Mic,
  MicOff,
  Sparkles,
  Sliders,
  Video,
  CheckCircle2,
  Users,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Streamer } from '../../types';

export const GoLiveScreen: React.FC = () => {
  const { currentUser, enterLiveRoom, setCurrentScreen } = useApp();

  const [streamTitle, setStreamTitle] = useState('✨ Chill Live Session & Community Chat! 🌟');
  const [selectedCategory, setSelectedCategory] = useState<'Popular' | 'Music' | 'Gaming' | 'Chat' | 'PK Battle'>('Chat');
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [beautyLevel, setBeautyLevel] = useState(60);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let activeStream: MediaStream | null = null;
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: true })
        .then((stream) => {
          activeStream = stream;
          setCameraStream(stream);
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch((err) => {
          console.warn('Camera preview simulated:', err);
        });
    }

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const handleStartBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    // Create a temporary live streamer profile for current user
    const myBroadcastStreamer: Streamer = {
      id: `my_stream_${Date.now()}`,
      username: currentUser.username,
      displayName: currentUser.displayName,
      avatar: currentUser.avatar,
      coverImage: currentUser.avatar,
      title: streamTitle.trim() || 'Live with community',
      category: selectedCategory,
      tags: ['Live', selectedCategory, 'Interactive'],
      viewersCount: 142,
      likesCount: 890,
      diamondsEarned: 240,
      isLive: true,
      bio: currentUser.bio,
      followersCount: currentUser.followersCount,
    };

    enterLiveRoom(myBroadcastStreamer);
  };

  const categories = ['Chat', 'Music', 'Gaming', 'PK Battle', 'Popular'] as const;

  return (
    <div className="relative h-screen max-w-lg mx-auto bg-[#080911] text-white flex flex-col justify-between overflow-hidden select-none">
      {/* Background Camera Feed / Simulated Studio */}
      <div className="absolute inset-0 z-0 bg-slate-900">
        {cameraStream ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover scale-x-[-1]"
            style={{ filter: `contrast(${100 + beautyLevel * 0.1}%) saturate(${100 + beautyLevel * 0.15}%)` }}
          />
        ) : (
          <div className="w-full h-full relative">
            <img
              src={
                currentUser?.avatar ||
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80'
              }
              alt="Camera preview"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
              style={{ filter: `contrast(${100 + beautyLevel * 0.1}%) brightness(1.05)` }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#080911] via-black/40 to-black/70" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#080911] via-transparent to-black/60" />
      </div>

      {/* Top Header */}
      <div className="relative z-20 pt-4 px-4 flex items-center justify-between">
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-xl border border-white/10 text-xs font-bold text-pink-400">
          <Radio className="w-3.5 h-3.5 animate-pulse" />
          <span>Broadcast Studio</span>
        </div>

        <button
          onClick={() => setCurrentScreen('home')}
          className="w-9 h-9 rounded-full bg-black/60 backdrop-blur-xl border border-white/15 text-white flex items-center justify-center hover:bg-black/80"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Broadcast Form & Controls */}
      <div className="relative z-20 p-4 space-y-4 max-w-md mx-auto w-full">
        {/* Title Input Card */}
        <div className="p-3.5 rounded-3xl bg-black/60 backdrop-blur-xl border border-white/15 space-y-3">
          <label className="block text-[11px] font-bold text-slate-300">
            Stream Title & Topics
          </label>
          <input
            type="text"
            value={streamTitle}
            onChange={(e) => setStreamTitle(e.target.value)}
            placeholder="What are you streaming today?"
            className="w-full px-3 py-2.5 rounded-xl bg-white/10 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500 font-medium"
          />

          {/* Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
                    : 'bg-white/5 text-slate-300 hover:bg-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Studio Quick Toggles */}
        <div className="p-3 rounded-2xl bg-black/60 backdrop-blur-xl border border-white/15 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-pink-400" />
              <span>Studio Beauty Glow</span>
            </span>
            <span className="text-xs font-bold text-pink-400">{beautyLevel}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={beautyLevel}
            onChange={(e) => setBeautyLevel(Number(e.target.value))}
            className="w-full accent-pink-500 cursor-pointer"
          />
        </div>

        {/* Start Button */}
        <button
          onClick={handleStartBroadcast}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 hover:opacity-95 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-pink-500/40 active:scale-[0.98] transition-all"
        >
          <Radio className="w-5 h-5 text-white animate-pulse" />
          <span>GO LIVE NOW</span>
        </button>
      </div>
    </div>
  );
};
