import React, { useState } from 'react';
import {
  Sparkles,
  Lock,
  Mail,
  User as UserIcon,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Users,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AuthScreen: React.FC = () => {
  const { loginUser, signupUser, setCurrentScreen, streamers } = useApp();
  const [mode, setMode] = useState<'login' | 'signup'>('login');

  // Form states
  const [username, setUsername] = useState('adil_star');
  const [password, setPassword] = useState('password123');
  const [fullName, setFullName] = useState('Adil Khan');
  const [email, setEmail] = useState('adil@example.com');
  const [bio, setBio] = useState('Live streaming & music lover on LiveStar 🌟');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    try {
      if (mode === 'login') {
        const res = await loginUser(username, password);
        if (!res.success) {
          setErrorMessage(res.error || 'Login failed. Please check your username handle.');
        }
      } else {
        const res = await signupUser(username, email, fullName, bio);
        if (!res.success) {
          setErrorMessage(res.error || 'Registration failed. Please choose another username.');
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred connecting to database.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickLogin = async (userHandle: string) => {
    setErrorMessage(null);
    setIsLoading(true);
    try {
      const res = await loginUser(userHandle);
      if (!res.success) {
        setErrorMessage(res.error || 'Failed to switch user.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen max-w-lg mx-auto px-4 py-8 flex flex-col justify-between bg-[#080911] text-white select-none">
      {/* Brand Lockup */}
      <div className="text-center space-y-2 pt-4">
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-600 flex items-center justify-center shadow-xl shadow-pink-500/30 mx-auto transform hover:rotate-6 transition-transform">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h1 className="font-display font-extrabold text-2xl tracking-tight bg-gradient-to-r from-white via-pink-200 to-purple-400 bg-clip-text text-transparent">
          LiveStar
        </h1>
        <p className="text-xs text-slate-400 max-w-xs mx-auto">
          The real-time live streaming social universe. All accounts sync across devices through the shared database.
        </p>
      </div>

      {/* Main Card */}
      <div className="my-5 p-5 rounded-3xl bg-[#121626]/80 border border-white/10 backdrop-blur-xl shadow-2xl space-y-4">
        {/* Toggle Mode */}
        <div className="flex items-center p-1 bg-white/5 rounded-2xl border border-white/5">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              mode === 'login'
                ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              mode === 'signup'
                ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Register Account
          </button>
        </div>

        {/* Error Feedback Message */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <span className="leading-snug">{errorMessage}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === 'signup' && (
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">Full Name</label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Alex Johnson"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
                  required
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-[11px] font-bold text-slate-300 mb-1">
              Username Handle (Unique ID)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-mono">@</span>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                placeholder="unique_handle"
                className="w-full pl-8 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
                required
              />
            </div>
            {mode === 'signup' && (
              <p className="text-[10px] text-slate-400 mt-0.5">
                Every user is assigned a permanent unique ID (e.g. usr_...) in the shared database.
              </p>
            )}
          </div>

          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Bio</label>
                <input
                  type="text"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Short bio or streaming focus..."
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-[11px] font-bold text-slate-300 mb-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 hover:opacity-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-500/30 active:scale-[0.98] disabled:opacity-50 transition-all cursor-pointer"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <span>{mode === 'login' ? 'Sign In' : 'Register into Shared Database'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Registered Community Accounts from Shared Database */}
        {streamers.length > 0 && (
          <div className="pt-3 border-t border-white/10 space-y-2">
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3 text-pink-400" />
                <span>Registered in Shared Database ({streamers.length})</span>
              </span>
              <span className="text-emerald-400 lowercase">live sync</span>
            </div>

            <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto no-scrollbar">
              {streamers.slice(0, 6).map((user) => (
                <button
                  key={user.id}
                  type="button"
                  onClick={() => handleQuickLogin(user.username)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] text-slate-200 flex items-center gap-2 transition-colors text-left"
                  title={`Log in as @${user.username} (ID: ${user.id})`}
                >
                  <img
                    src={user.avatar}
                    alt={user.displayName}
                    className="w-6 h-6 rounded-full object-cover shrink-0 border border-pink-500/40"
                  />
                  <div className="min-w-0">
                    <span className="font-bold text-white block truncate text-[11px]">
                      {user.displayName}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono block truncate">
                      @{user.username}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="text-center space-y-2 pb-4">
        <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Shared Multi-Device Database · Permanent Unique IDs</span>
        </div>
        <button
          onClick={() => setCurrentScreen('home')}
          className="text-xs text-pink-400 hover:text-pink-300 font-semibold underline underline-offset-4"
        >
          Explore Registered Users as Guest →
        </button>
      </div>
    </div>
  );
};
