import React, { useState } from 'react';
import { X, Coins, Sparkles, Plus, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GiftItem } from '../../types';

interface GiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  streamerId: string;
  streamerName: string;
}

export const GiftModal: React.FC<GiftModalProps> = ({
  isOpen,
  onClose,
  streamerId,
  streamerName,
}) => {
  const { gifts, currentUser, sendGift, setCurrentScreen } = useApp();
  const [selectedGift, setSelectedGift] = useState<GiftItem>(gifts[0]);
  const [multiplier, setMultiplier] = useState<number>(1);
  const [feedbackMessage, setFeedbackMessage] = useState<{ text: string; error?: boolean } | null>(null);

  if (!isOpen) return null;

  const totalCost = selectedGift ? selectedGift.cost * multiplier : 0;
  const userCoins = currentUser?.coinsCount ?? 0;
  const canAfford = userCoins >= totalCost;

  const handleSend = () => {
    if (!selectedGift) return;

    if (!canAfford) {
      setFeedbackMessage({
        text: `Insufficient coins (${userCoins.toLocaleString()} available). Top up to send!`,
        error: true,
      });
      setTimeout(() => setFeedbackMessage(null), 3000);
      return;
    }

    const success = sendGift(selectedGift, streamerId, multiplier);
    if (success) {
      setFeedbackMessage({
        text: `Sent ${multiplier}x ${selectedGift.name} to ${streamerName}! 🚀`,
        error: false,
      });
      setTimeout(() => {
        setFeedbackMessage(null);
        onClose();
      }, 1200);
    }
  };

  const multipliers = [1, 5, 10, 66, 99];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#0f1220] rounded-t-3xl border-t border-white/10 p-4 shadow-2xl flex flex-col max-h-[85vh] animate-in slide-in-from-bottom duration-300">
        {/* Grab Handle */}
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mb-3" />

        {/* Header & Wallet Balance */}
        <div className="flex items-center justify-between pb-3 border-b border-white/5">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-base text-white">Send Gifts</span>
            <span className="text-xs text-slate-400">to {streamerName}</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>{userCoins.toLocaleString()}</span>
              <button
                onClick={() => {
                  onClose();
                  setCurrentScreen('wallet');
                }}
                className="w-4 h-4 ml-1 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-extrabold hover:bg-amber-300"
                title="Top up coins"
              >
                +
              </button>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedbackMessage && (
          <div
            className={`my-2 p-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 ${
              feedbackMessage.error
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
            }`}
          >
            {feedbackMessage.error ? (
              <AlertCircle className="w-4 h-4 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            )}
            <span>{feedbackMessage.text}</span>
          </div>
        )}

        {/* Gifts Grid */}
        <div className="grid grid-cols-4 gap-2.5 my-3 overflow-y-auto max-h-64 pr-1">
          {gifts.map((gift) => {
            const isSelected = selectedGift.id === gift.id;
            return (
              <button
                key={gift.id}
                onClick={() => setSelectedGift(gift)}
                className={`relative flex flex-col items-center justify-center p-2 rounded-2xl border transition-all text-center ${
                  isSelected
                    ? 'bg-gradient-to-b from-pink-500/20 to-purple-600/30 border-pink-500 shadow-md shadow-pink-500/20 scale-102'
                    : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/15'
                }`}
              >
                {/* Gift Icon */}
                <span className="text-3xl filter drop-shadow-md my-1">{gift.icon}</span>

                {/* Gift Name */}
                <span className="text-[11px] font-semibold text-slate-200 truncate w-full">
                  {gift.name}
                </span>

                {/* Coin Cost */}
                <div className="flex items-center gap-1 text-[10px] text-amber-300 font-bold mt-0.5">
                  <Coins className="w-3 h-3 text-amber-400" />
                  <span>{gift.cost.toLocaleString()}</span>
                </div>

                {gift.rarity === 'Legendary' && (
                  <span className="absolute -top-1 -right-1 px-1 rounded-full bg-gradient-to-r from-amber-400 to-rose-500 text-[8px] font-extrabold text-slate-950">
                    VIP
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Multipliers & Action Bar */}
        <div className="pt-2 border-t border-white/5 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Combo Count:</span>
            <div className="flex items-center gap-1">
              {multipliers.map((m) => (
                <button
                  key={m}
                  onClick={() => setMultiplier(m)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                    multiplier === m
                      ? 'bg-pink-500 text-white shadow-sm'
                      : 'bg-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  x{m}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                setCurrentScreen('wallet');
              }}
              className="px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors shrink-0"
            >
              <Plus className="w-3.5 h-3.5 text-amber-400" />
              <span>Get Coins</span>
            </button>

            <button
              onClick={handleSend}
              className={`flex-1 py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg ${
                canAfford
                  ? 'bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 text-white shadow-pink-500/30 hover:opacity-95 active:scale-[0.98]'
                  : 'bg-white/10 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>
                Send {multiplier > 1 ? `${multiplier}x ` : ''}
                {selectedGift.name} ({totalCost.toLocaleString()} Coins)
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
