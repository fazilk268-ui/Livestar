import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Heart,
  Send,
  Gift,
  PhoneCall,
  Share2,
  Volume2,
  VolumeX,
  Users,
  Sparkles,
  UserCheck,
  UserPlus,
  Flame,
  MessageSquare,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GiftModal } from './GiftModal';
import { LiveComment } from '../../types';

export const LiveRoomScreen: React.FC = () => {
  const {
    activeStreamer,
    currentUser,
    toggleFollow,
    startVideoCall,
    triggerHeart,
    latestGiftBanner,
    setCurrentScreen,
  } = useApp();

  const [comments, setComments] = useState<LiveComment[]>([
    {
      id: 'c1',
      userId: 'u1',
      username: 'neon_rider',
      userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
      text: 'This beat is unbelievable! Tokyo vibe is real 🔥🔥',
      badgeLevel: 14,
      timestamp: '1m ago',
    },
    {
      id: 'c2',
      userId: 'u2',
      username: 'chloe_vibes',
      userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80',
      text: 'Loving the lighting setup tonight! So gorgeous ✨',
      badgeLevel: 8,
      timestamp: '45s ago',
    },
    {
      id: 'c3',
      userId: 'u3',
      username: 'gamer_zack',
      userAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=120&q=80',
      text: 'Just sent a Galaxy Rocket! Keep rocking the decks 🚀',
      badgeLevel: 25,
      timestamp: '20s ago',
      isGift: true,
      giftName: 'Galaxy Rocket',
      giftIcon: '🚀',
      giftCount: 1,
    },
  ]);

  const [inputMessage, setInputMessage] = useState<string>('');
  const [isGiftModalOpen, setIsGiftModalOpen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [hearts, setHearts] = useState<{ id: number; left: number }[]>([]);
  const [copiedShare, setCopiedShare] = useState<boolean>(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [comments]);

  // Simulate incoming live viewers comments periodically
  useEffect(() => {
    const sampleBots = [
      { name: 'mika_sound', text: 'Play that drop again please! 🎶', badge: 6 },
      { name: 'david_k', text: 'Hello from Singapore! Amazing energy ❤️', badge: 12 },
      { name: 'luna_star', text: 'Sent you roses! 🌹🌹🌹', badge: 9 },
      { name: 'ryo_pixel', text: 'Can we do 1v1 video call later? 📱', badge: 17 },
      { name: 'elena_fan', text: 'You are so talented! 👑', badge: 15 },
    ];

    const interval = setInterval(() => {
      const randomBot = sampleBots[Math.floor(Math.random() * sampleBots.length)];
      const newComment: LiveComment = {
        id: `bot_${Date.now()}`,
        userId: `bot_${Math.random()}`,
        username: randomBot.name,
        userAvatar: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 50000000)}?auto=format&fit=crop&w=100&q=80`,
        text: randomBot.text,
        badgeLevel: randomBot.badge,
        timestamp: 'Just now',
      };
      setComments((prev) => [...prev.slice(-40), newComment]);
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  if (!activeStreamer) {
    return (
      <div className="h-screen flex items-center justify-center p-4">
        <button
          onClick={() => setCurrentScreen('home')}
          className="px-4 py-2 rounded-xl bg-pink-600 text-white text-sm"
        >
          Return to Home
        </button>
      </div>
    );
  }

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newComment: LiveComment = {
      id: `c_${Date.now()}`,
      userId: currentUser?.id || 'guest',
      username: currentUser?.displayName || 'LiveStar VIP',
      userAvatar:
        currentUser?.avatar ||
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      text: inputMessage.trim(),
      badgeLevel: currentUser?.level || 1,
      timestamp: 'Just now',
    };

    setComments((prev) => [...prev, newComment]);
    setInputMessage('');
    triggerHeart();
  };

  const spawnHeart = (e?: React.MouseEvent) => {
    triggerHeart();
    const xPos = e ? Math.min(Math.max(e.clientX - 20, 20), window.innerWidth - 60) : Math.random() * 80 + 10;
    const newHeart = { id: Date.now() + Math.random(), left: xPos };
    setHearts((prev) => [...prev, newHeart]);

    setTimeout(() => {
      setHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 2200);
  };

  const handleShare = () => {
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  return (
    <div className="relative h-screen w-full bg-[#080911] overflow-hidden flex flex-col justify-between select-none">
      {/* Background Video Stream Representation */}
      <div
        className="absolute inset-0 z-0 bg-cover bg-center cursor-pointer"
        style={{ backgroundImage: `url(${activeStreamer.coverImage})` }}
        onClick={spawnHeart}
      >
        {/* Cinematic dark scrim for crisp text contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/90" />
        <div className="absolute inset-0 bg-radial from-transparent via-transparent to-black/60" />

        {/* Floating Sound Waves & Equalizer Indicator */}
        <div className="absolute top-20 right-4 flex items-end gap-0.5 px-2.5 py-1.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10">
          <div className="w-1 h-3 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-1 h-5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-1 h-4 bg-pink-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          <span className="text-[10px] text-slate-200 ml-1 font-semibold">1080p HD</span>
        </div>
      </div>

      {/* Floating Animated Hearts Area */}
      <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden">
        {hearts.map((h) => (
          <div
            key={h.id}
            className="absolute bottom-28 animate-float-heart text-2xl filter drop-shadow-lg"
            style={{ left: `${h.left % 300 + 40}px` }}
          >
            {['💖', '✨', '🔥', '🌸', '💜'][Math.floor(Math.random() * 5)]}
          </div>
        ))}
      </div>

      {/* Gift Announcement Banner */}
      {latestGiftBanner && (
        <div className="absolute top-24 left-3 right-3 z-30 animate-gift-burst">
          <div className="p-3 rounded-2xl bg-gradient-to-r from-pink-600/95 via-purple-600/95 to-amber-500/95 border border-white/30 backdrop-blur-xl shadow-2xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="text-3xl animate-spin">{latestGiftBanner.giftIcon}</span>
              <div>
                <p className="text-xs font-bold text-white leading-tight">
                  <span className="text-amber-200 font-extrabold">{latestGiftBanner.sender}</span> sent{' '}
                  <span className="text-white underline">{latestGiftBanner.giftName}</span>!
                </p>
                <p className="text-[10px] text-pink-100">Super Supporter Combo x{latestGiftBanner.count}</p>
              </div>
            </div>
            <div className="px-2 py-1 rounded-full bg-black/30 text-amber-300 text-xs font-black">
              x{latestGiftBanner.count}
            </div>
          </div>
        </div>
      )}

      {/* Share Copied Toast */}
      {copiedShare && (
        <div className="absolute top-36 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-full bg-emerald-500/90 text-white text-xs font-bold backdrop-blur-md shadow-xl animate-bounce">
          ✓ Stream link copied to clipboard!
        </div>
      )}

      {/* TOP STREAMER BAR */}
      <div className="relative z-20 pt-3 px-3 flex items-center justify-between gap-2">
        {/* Streamer Profile Card */}
        <div className="flex items-center gap-2 p-1 pl-1 pr-3 rounded-full bg-black/50 backdrop-blur-xl border border-white/15">
          <img
            src={activeStreamer.avatar}
            alt={activeStreamer.displayName}
            referrerPolicy="no-referrer"
            className="w-9 h-9 rounded-full object-cover border border-pink-400 shrink-0"
          />
          <div className="flex flex-col min-w-0 max-w-[110px]">
            <span className="text-xs font-bold text-white truncate">
              {activeStreamer.displayName}
            </span>
            <div className="flex items-center gap-1 text-[10px] text-amber-300 font-medium">
              <Flame className="w-2.5 h-2.5 text-amber-400" />
              <span>{(activeStreamer.diamondsEarned / 1000).toFixed(1)}k</span>
            </div>
          </div>

          {/* Follow Button */}
          <button
            onClick={() => toggleFollow(activeStreamer.id)}
            className={`ml-1 px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all ${
              activeStreamer.isFollowing
                ? 'bg-white/15 text-pink-300'
                : 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-md shadow-pink-500/30'
            }`}
          >
            {activeStreamer.isFollowing ? (
              <>
                <UserCheck className="w-3 h-3" />
                <span>Joined</span>
              </>
            ) : (
              <>
                <UserPlus className="w-3 h-3" />
                <span>Follow</span>
              </>
            )}
          </button>
        </div>

        {/* Right Top Actions */}
        <div className="flex items-center gap-1.5">
          {/* Live Viewers Count */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/50 backdrop-blur-xl border border-white/10 text-white text-xs font-medium">
            <Users className="w-3 h-3 text-pink-400" />
            <span className="tabular-nums">
              {(activeStreamer.viewersCount / 1000).toFixed(1)}k
            </span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={() => setIsMuted((prev) => !prev)}
            className="w-8 h-8 rounded-full bg-black/50 backdrop-blur-xl border border-white/10 text-white flex items-center justify-center hover:bg-black/70"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Close Room */}
          <button
            onClick={() => setCurrentScreen('home')}
            className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-xl border border-white/20 text-white flex items-center justify-center hover:bg-rose-600/80 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* CENTER & BOTTOM: CHAT & INTERACTION CONTROLS */}
      <div className="relative z-20 p-3 flex flex-col justify-end space-y-3 max-w-lg mx-auto w-full">
        {/* Floating Chat Comments Container */}
        <div className="max-h-56 sm:max-h-64 overflow-y-auto space-y-1.5 pr-2 mask-linear-fade">
          {comments.map((comment) => (
            <div
              key={comment.id}
              className={`p-2 rounded-2xl backdrop-blur-md border text-xs max-w-[85%] transition-all ${
                comment.isGift
                  ? 'bg-gradient-to-r from-pink-600/40 to-purple-600/40 border-pink-500/40 text-amber-200'
                  : 'bg-black/40 border-white/10 text-slate-100'
              }`}
            >
              <div className="flex items-center gap-1.5 mb-0.5">
                <span className="px-1.5 py-0.2 rounded-md bg-gradient-to-r from-pink-500 to-purple-600 text-[9px] font-extrabold text-white">
                  Lv.{comment.badgeLevel}
                </span>
                <span className="font-bold text-pink-300 truncate">{comment.username}</span>
                {comment.isGift && (
                  <span className="text-[10px] text-amber-300 font-extrabold">GIFT VIP</span>
                )}
              </div>
              <p className="leading-snug text-white/90 break-words">{comment.text}</p>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>

        {/* BOTTOM ACTION BAR */}
        <div className="flex items-center gap-2 pt-1">
          {/* Chat Input Form */}
          <form onSubmit={handleSendComment} className="flex-1 relative">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Say something nice..."
              className="w-full pl-3 pr-10 py-2.5 rounded-full bg-black/60 backdrop-blur-xl border border-white/20 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500 focus:ring-1 focus:ring-pink-500 transition-all"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim()}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-pink-500 text-white flex items-center justify-center disabled:opacity-40 hover:bg-pink-400 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* 1-on-1 Video Call Action Button */}
          <button
            onClick={() => startVideoCall(activeStreamer)}
            title="Invite to 1-on-1 Video Call"
            className="w-10 h-10 rounded-full bg-purple-600/90 hover:bg-purple-500 backdrop-blur-xl text-white flex items-center justify-center shadow-lg shadow-purple-600/30 active:scale-95 transition-transform shrink-0"
          >
            <PhoneCall className="w-4 h-4" />
          </button>

          {/* Virtual Gift Button */}
          <button
            onClick={() => setIsGiftModalOpen(true)}
            title="Send Gift"
            className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 backdrop-blur-xl text-white flex items-center justify-center shadow-lg shadow-pink-500/30 active:scale-95 transition-transform shrink-0 animate-pulse"
          >
            <Gift className="w-4 h-4" />
          </button>

          {/* Share Button */}
          <button
            onClick={handleShare}
            title="Share stream"
            className="w-10 h-10 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-xl border border-white/15 text-slate-200 flex items-center justify-center active:scale-95 transition-transform shrink-0"
          >
            <Share2 className="w-4 h-4" />
          </button>

          {/* Like Heart Button */}
          <button
            onClick={(e) => spawnHeart(e)}
            title="Double tap or click to send love"
            className="w-10 h-10 rounded-full bg-rose-600/80 hover:bg-rose-500 backdrop-blur-xl text-white flex items-center justify-center active:scale-125 transition-all shrink-0"
          >
            <Heart className="w-4 h-4 fill-white" />
          </button>
        </div>
      </div>

      {/* Gift Modal Bottom Sheet */}
      <GiftModal
        isOpen={isGiftModalOpen}
        onClose={() => setIsGiftModalOpen(false)}
        streamerId={activeStreamer.id}
        streamerName={activeStreamer.displayName}
      />
    </div>
  );
};
