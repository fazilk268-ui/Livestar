import React, { useState } from 'react';
import {
  Coins,
  Flame,
  ArrowDownLeft,
  ArrowUpRight,
  Sparkles,
  CreditCard,
  History,
  CheckCircle2,
  DollarSign,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const WalletScreen: React.FC = () => {
  const { currentUser, transactions, rechargeCoins, cashoutDiamonds } = useApp();
  const [activeTab, setActiveTab] = useState<'recharge' | 'cashout' | 'history'>('recharge');
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<string>('all');

  const coinPackages = [
    { coins: 100, bonus: 0, price: '$0.99', popular: false },
    { coins: 500, bonus: 50, price: '$4.99', popular: false },
    { coins: 1200, bonus: 200, price: '$9.99', popular: true },
    { coins: 3000, bonus: 600, price: '$24.99', popular: false },
    { coins: 7500, bonus: 1800, price: '$59.99', popular: false },
    { coins: 15000, bonus: 4000, price: '$119.99', popular: false },
  ];

  const handleRecharge = (pkg: (typeof coinPackages)[0]) => {
    const totalAdded = pkg.coins + pkg.bonus;
    rechargeCoins(totalAdded, `${pkg.price} pack`);
    setSuccessToast(`Successfully recharged +${totalAdded.toLocaleString()} Coins! 🎉`);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  const handleCashout = (diamonds: number) => {
    if (!currentUser || currentUser.diamondsCount < diamonds) {
      alert('Insufficient diamonds for this cashout amount.');
      return;
    }
    const success = cashoutDiamonds(diamonds);
    if (success) {
      setSuccessToast(`Cashout request submitted for $${(diamonds / 200).toFixed(2)} USD! 💳`);
      setTimeout(() => setSuccessToast(null), 3000);
    }
  };

  const filteredTransactions = transactions.filter((tx) => {
    if (filterType === 'all') return true;
    if (filterType === 'recharge') return tx.type === 'recharge';
    if (filterType === 'gifts') return tx.type === 'gift_sent';
    if (filterType === 'earnings') return tx.type === 'gift_received' || tx.type === 'cashout';
    return true;
  });

  return (
    <div className="pb-24 pt-2 px-3 max-w-lg mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="font-display font-bold text-lg text-white">LiveStar Wallet</h1>
        <span className="text-[10px] text-amber-300 font-bold px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
          PROTOTYPE TESTNET
        </span>
      </div>

      {/* Success Notification */}
      {successToast && (
        <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Balance Dual Cards */}
      <div className="grid grid-cols-2 gap-3">
        {/* Coins Card */}
        <div className="p-4 rounded-3xl bg-gradient-to-br from-amber-500/20 via-pink-500/15 to-[#121626] border border-amber-500/30 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
              <Coins className="w-3.5 h-3.5" />
              Coins Balance
            </span>
          </div>
          <div className="text-2xl font-black text-white tabular-nums tracking-tight">
            {currentUser?.coinsCount.toLocaleString() ?? 0}
          </div>
          <p className="text-[10px] text-slate-300 mt-1">Used to send gifts & tip streamers</p>
        </div>

        {/* Diamonds Card */}
        <div className="p-4 rounded-3xl bg-gradient-to-br from-purple-600/20 via-pink-600/15 to-[#121626] border border-purple-500/30 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-purple-300 flex items-center gap-1">
              <Flame className="w-3.5 h-3.5" />
              Diamonds Earned
            </span>
          </div>
          <div className="text-2xl font-black text-white tabular-nums tracking-tight">
            {currentUser?.diamondsCount.toLocaleString() ?? 0}
          </div>
          <p className="text-[10px] text-slate-300 mt-1">
            ≈ ${((currentUser?.diamondsCount || 0) / 200).toFixed(2)} USD Payout
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center p-1 bg-white/5 rounded-2xl border border-white/5">
        <button
          onClick={() => setActiveTab('recharge')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'recharge'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Recharge Coins
        </button>

        <button
          onClick={() => setActiveTab('cashout')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'cashout'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Creator Payout
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'history'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Transactions
        </button>
      </div>

      {/* RECHARGE TAB */}
      {activeTab === 'recharge' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Select a coin package to top up</span>
            <span className="text-amber-400 font-semibold flex items-center gap-1">
              <Zap className="w-3 h-3" /> Instant Credit
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {coinPackages.map((pkg, idx) => (
              <div
                key={idx}
                className={`relative p-3.5 rounded-2xl border transition-all flex flex-col justify-between ${
                  pkg.popular
                    ? 'bg-gradient-to-b from-pink-500/20 to-purple-600/20 border-pink-500 shadow-lg shadow-pink-500/10'
                    : 'bg-white/5 border-white/10 hover:border-white/20'
                }`}
              >
                {pkg.popular && (
                  <span className="absolute -top-2 right-3 px-2 py-0.5 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 text-[9px] font-extrabold text-white shadow">
                    MOST POPULAR
                  </span>
                )}

                <div>
                  <div className="flex items-center gap-1.5 text-amber-300 font-extrabold text-base">
                    <Coins className="w-4 h-4 text-amber-400" />
                    <span>{pkg.coins.toLocaleString()}</span>
                  </div>

                  {pkg.bonus > 0 && (
                    <div className="text-[10px] text-pink-400 font-bold mt-0.5">
                      +{pkg.bonus.toLocaleString()} Extra Bonus
                    </div>
                  )}
                </div>

                <button
                  onClick={() => handleRecharge(pkg)}
                  className="mt-3 w-full py-2 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white text-xs font-bold shadow-md shadow-pink-500/20 active:scale-[0.98] transition-all"
                >
                  {pkg.price}
                </button>
              </div>
            ))}
          </div>

          <div className="p-3 rounded-2xl bg-white/5 border border-white/5 flex items-start gap-2.5 text-xs text-slate-400">
            <CreditCard className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              This is a functional frontend demo prototype. Tapping any package simulates an instant verified top-up and updates your live balance immediately.
            </p>
          </div>
        </div>
      )}

      {/* CASHOUT TAB */}
      {activeTab === 'cashout' && (
        <div className="space-y-4">
          <div className="p-4 rounded-3xl bg-white/5 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Creator Earnings Cashout</h3>
                <p className="text-[11px] text-slate-400 mt-0.5">Exchange diamonds for real payout</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">Rate</span>
                <span className="text-xs font-bold text-purple-300">200 💎 = $1.00 USD</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
              <span className="text-xs text-slate-300">Available to withdraw:</span>
              <span className="text-sm font-bold text-emerald-400 tabular-nums">
                ${((currentUser?.diamondsCount || 0) / 200).toFixed(2)} USD
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1">
              {[2000, 5000, 10000].map((diamonds) => {
                const usd = (diamonds / 200).toFixed(2);
                const hasEnough = (currentUser?.diamondsCount || 0) >= diamonds;
                return (
                  <button
                    key={diamonds}
                    onClick={() => handleCashout(diamonds)}
                    disabled={!hasEnough}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      hasEnough
                        ? 'bg-purple-600/20 border-purple-500/40 hover:bg-purple-600/30 text-white'
                        : 'bg-white/5 border-white/5 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <span className="block text-xs font-bold">${usd}</span>
                    <span className="text-[10px] text-purple-300 font-semibold">
                      {diamonds.toLocaleString()} 💎
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TRANSACTIONS HISTORY TAB */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          <div className="flex items-center gap-1 overflow-x-auto pb-1">
            {['all', 'recharge', 'gifts', 'earnings'].map((f) => (
              <button
                key={f}
                onClick={() => setFilterType(f)}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold capitalize whitespace-nowrap ${
                  filterType === f
                    ? 'bg-white/20 text-white'
                    : 'bg-white/5 text-slate-400 hover:text-white'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="space-y-2">
            {filteredTransactions.map((tx) => (
              <div
                key={tx.id}
                className="p-3 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      tx.amountCoins > 0 || (tx.amountDiamonds && tx.amountDiamonds > 0)
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    {tx.amountCoins > 0 || (tx.amountDiamonds && tx.amountDiamonds > 0) ? (
                      <ArrowDownLeft className="w-4 h-4" />
                    ) : (
                      <ArrowUpRight className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white truncate max-w-[180px]">
                      {tx.title}
                    </h4>
                    <p className="text-[10px] text-slate-400">{tx.subtitle} · {tx.timestamp}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  {tx.amountCoins !== 0 && (
                    <span
                      className={`text-xs font-bold tabular-nums block ${
                        tx.amountCoins > 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {tx.amountCoins > 0 ? `+${tx.amountCoins.toLocaleString()}` : tx.amountCoins.toLocaleString()}{' '}
                      Coins
                    </span>
                  )}
                  {tx.amountDiamonds && (
                    <span
                      className={`text-[11px] font-bold tabular-nums block ${
                        tx.amountDiamonds > 0 ? 'text-purple-300' : 'text-slate-400'
                      }`}
                    >
                      {tx.amountDiamonds > 0 ? `+${tx.amountDiamonds}` : tx.amountDiamonds} 💎
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
