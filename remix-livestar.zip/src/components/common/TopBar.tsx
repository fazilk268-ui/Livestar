import React from 'react';
import { Search, Bell, Coins, Sparkles, Smartphone, Monitor } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const TopBar: React.FC = () => {
  const {
    currentUser,
    notifications,
    setCurrentScreen,
    currentScreen,
    deviceFrameEnabled,
    setDeviceFrameEnabled,
  } = useApp();

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="sticky top-0 z-30 bg-[#080911]/95 backdrop-blur-md border-b border-white/5 px-3 py-2.5 flex items-center justify-between gap-2">
      {/* Brand */}
      <div
        onClick={() => setCurrentScreen('home')}
        className="flex items-center gap-2 cursor-pointer select-none group shrink-0"
      >
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-600 flex items-center justify-center shadow-lg shadow-pink-500/20 group-hover:scale-105 transition-transform">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-1">
            <span className="font-display font-bold text-lg tracking-tight bg-gradient-to-r from-white via-pink-100 to-pink-400 bg-clip-text text-transparent">
              LiveStar
            </span>
            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-pink-500/20 text-pink-400 border border-pink-500/30">
              LIVE
            </span>
          </div>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2">
        {/* Device Frame Viewport Toggle (helpful for desktop reviewers) */}
        <button
          onClick={() => setDeviceFrameEnabled((prev) => !prev)}
          title={deviceFrameEnabled ? 'Switch to Fluid Responsive Mode' : 'Switch to Android Phone Preview Frame'}
          className="hidden sm:flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors"
        >
          {deviceFrameEnabled ? (
            <>
              <Monitor className="w-3.5 h-3.5 text-purple-400" />
              <span>Full View</span>
            </>
          ) : (
            <>
              <Smartphone className="w-3.5 h-3.5 text-pink-400" />
              <span>Phone Frame</span>
            </>
          )}
        </button>

        {/* Coins Wallet Pill */}
        <button
          onClick={() => setCurrentScreen('wallet')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-500/10 to-pink-500/10 hover:from-amber-500/20 hover:to-pink-500/20 border border-amber-500/30 text-amber-300 transition-colors text-xs font-semibold shadow-sm"
        >
          <Coins className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          <span className="tabular-nums">
            {currentUser?.coinsCount.toLocaleString() ?? 0}
          </span>
          <span className="text-[10px] bg-amber-400/20 text-amber-300 rounded-full px-1 font-bold">
            +
          </span>
        </button>

        {/* Notifications Icon */}
        <button
          onClick={() => setCurrentScreen('inbox')}
          className="relative w-9 h-9 rounded-full flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
          aria-label="Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-pink-500 ring-2 ring-[#080911]" />
          )}
        </button>

        {/* Mini Profile Trigger */}
        {currentUser ? (
          <button
            onClick={() => setCurrentScreen('profile')}
            className={`w-8 h-8 rounded-full overflow-hidden border-2 transition-transform hover:scale-105 ${
              currentScreen === 'profile' ? 'border-pink-500 ring-2 ring-pink-500/30' : 'border-white/20'
            }`}
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.displayName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </button>
        ) : (
          <button
            onClick={() => setCurrentScreen('auth')}
            className="px-3 py-1 rounded-full bg-pink-600 hover:bg-pink-500 text-white text-xs font-semibold transition-colors"
          >
            Login
          </button>
        )}
      </div>
    </header>
  );
};
