import React from 'react';
import { Home, Flame, Video, MessageCircle, User as UserIcon } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ScreenType } from '../../types';

export const BottomNav: React.FC = () => {
  const { currentScreen, setCurrentScreen, notifications, messageThreads } = useApp();

  // Calculate unread badge count
  const unreadMessages = messageThreads.reduce((acc, t) => acc + (t.unreadCount || 0), 0);
  const unreadNotifs = notifications.filter((n) => !n.isRead).length;
  const totalInboxUnread = unreadMessages + unreadNotifs;

  // Don't show bottom nav when inside active full-screen video room or 1-on-1 video call
  if (currentScreen === 'live_room' || currentScreen === 'video_call') {
    return null;
  }

  const navItems: { id: ScreenType; label: string; icon: React.ReactNode; isAction?: boolean }[] = [
    {
      id: 'home',
      label: 'Home',
      icon: <Home className="w-5 h-5" />,
    },
    {
      id: 'wallet',
      label: 'Wallet',
      icon: <Flame className="w-5 h-5" />,
    },
    {
      id: 'go_live',
      label: 'Go Live',
      icon: <Video className="w-6 h-6 text-white" />,
      isAction: true,
    },
    {
      id: 'inbox',
      label: 'Inbox',
      icon: (
        <div className="relative">
          <MessageCircle className="w-5 h-5" />
          {totalInboxUnread > 0 && (
            <span className="absolute -top-1 -right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-pink-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-[#080911]">
              {totalInboxUnread}
            </span>
          )}
        </div>
      ),
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: <UserIcon className="w-5 h-5" />,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#080911]/95 backdrop-blur-xl border-t border-white/10 px-2 py-1.5 max-w-lg mx-auto">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          if (item.isAction) {
            return (
              <button
                key={item.id}
                onClick={() => setCurrentScreen('go_live')}
                className="relative -top-3 flex flex-col items-center justify-center focus:outline-none group"
              >
                <div className="w-13 h-13 rounded-full bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-600 p-[3px] shadow-lg shadow-pink-500/30 group-active:scale-95 transition-transform">
                  <div className="w-full h-full rounded-full bg-[#080911]/40 flex items-center justify-center backdrop-blur-sm">
                    {item.icon}
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-pink-300 mt-0.5">
                  {item.label}
                </span>
              </button>
            );
          }

          const isActive = currentScreen === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setCurrentScreen(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 min-w-[56px] rounded-xl transition-all ${
                isActive
                  ? 'text-pink-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className={`transition-transform ${isActive ? 'scale-110' : ''}`}>
                {item.icon}
              </div>
              <span className="text-[10px] mt-1 tracking-tight">
                {item.label}
              </span>
              {isActive && (
                <span className="w-1 h-1 rounded-full bg-pink-400 mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
