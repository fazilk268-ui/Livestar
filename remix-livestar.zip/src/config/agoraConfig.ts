/**
 * Agora RTC Configuration for LiveStar Video Calling
 *
 * App ID: c4a9cf6f9245456b929b79923f713952
 * Security Notice: App Certificate is managed strictly on the backend
 * (/api/agora/token) and is never exposed to client-side code.
 */

export interface AgoraSettings {
  appId: string;
  channelProfile: 'communication' | 'live';
  videoEncoding: '720p' | '1080p';
  tokenEndpoint: string;
  isConfigured: boolean;
}

export const AGORA_CONFIG: AgoraSettings = {
  // Official Agora App ID provided for LiveStar
  appId: 'c4a9cf6f9245456b929b79923f713952',
  channelProfile: 'communication',
  videoEncoding: '1080p',
  tokenEndpoint: '/api/agora/token',
  isConfigured: true,
};

/**
 * Returns a consistent, deterministic channel name for 1-on-1 video calls.
 * Ensures both participants join the exact same Agora channel regardless of who initiates.
 */
export const getAgoraChannelName = (
  userA: string,
  userB?: string,
  customRoom?: string
): string => {
  if (customRoom && customRoom.trim()) {
    return customRoom.trim().replace(/[^a-zA-Z0-9_-]/g, '');
  }
  const cleanA = (userA || 'user1').toLowerCase().replace(/[^a-z0-9_]/g, '');
  const cleanB = (userB || '').toLowerCase().replace(/[^a-z0-9_]/g, '');

  if (!cleanB) {
    return `livestar_call_${cleanA}`;
  }

  // Sort alphabetically so [A, B] and [B, A] always yield identical channel names
  const sorted = [cleanA, cleanB].sort();
  return `livestar_${sorted[0]}_${sorted[1]}`;
};

