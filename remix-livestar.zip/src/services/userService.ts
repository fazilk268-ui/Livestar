/**
 * Shared User Discovery & Authentication API Service
 * Connects frontend clients on different devices to the central shared database.
 */

import { User, Streamer } from '../types';

export interface ApiUserResponse {
  success: boolean;
  user?: Streamer;
  users?: Streamer[];
  count?: number;
  error?: string;
  message?: string;
}

export const userService = {
  /**
   * Fetches all registered users from the shared database.
   */
  async getAllUsers(category?: string): Promise<Streamer[]> {
    try {
      const url = category && category !== 'All' ? `/api/users?category=${encodeURIComponent(category)}` : '/api/users';
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: ApiUserResponse = await res.json();
      return data.users || [];
    } catch (err) {
      console.warn('[userService] Failed to fetch shared users:', err);
      return [];
    }
  },

  /**
   * Search registered users across all devices by handle, name, bio or tags.
   */
  async searchUsers(query: string): Promise<Streamer[]> {
    try {
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: ApiUserResponse = await res.json();
      return data.users || [];
    } catch (err) {
      console.warn('[userService] Search failed:', err);
      return [];
    }
  },

  /**
   * Fetches a specific user profile by unique ID.
   */
  async getUserById(id: string): Promise<Streamer | null> {
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(id)}`);
      if (!res.ok) return null;
      const data: ApiUserResponse = await res.json();
      return data.user || null;
    } catch (err) {
      console.warn('[userService] getUserById failed:', err);
      return null;
    }
  },

  /**
   * Registers a new user into the shared database.
   */
  async register(params: {
    username: string;
    displayName: string;
    email?: string;
    bio?: string;
    avatar?: string;
    category?: 'Popular' | 'Music' | 'Gaming' | 'Chat' | 'PK Battle';
  }): Promise<{ success: boolean; user?: Streamer; error?: string }> {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed' };
      }

      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error connecting to shared database' };
    }
  },

  /**
   * Logs in a user from the shared database by username handle.
   */
  async login(username: string): Promise<{ success: boolean; user?: Streamer; error?: string }> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Login failed' };
      }

      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error connecting to shared database' };
    }
  },

  /**
   * Toggles following a user in the shared database.
   */
  async toggleFollow(targetUserId: string, followerUserId: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(targetUserId)}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ followerId: followerUserId }),
      });
      return res.ok;
    } catch (err) {
      console.warn('[userService] toggleFollow error:', err);
      return false;
    }
  },

  /**
   * Checks database connectivity & status.
   */
  async getDatabaseStatus(): Promise<{ status: string; userCount: number; type: string } | null> {
    try {
      const res = await fetch('/api/database/status');
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },
};
