/**
 * Agora RTC Video Calling Service
 *
 * App ID: c4a9cf6f9245456b929b79923f713952
 * Full Agora WebRTC client implementation subscribing to remote streams,
 * publishing local video/audio, handling user joined/left events.
 */

import AgoraRTC, {
  IAgoraRTCClient,
  ICameraVideoTrack,
  IMicrophoneAudioTrack,
  IAgoraRTCRemoteUser,
  IRemoteVideoTrack,
  IRemoteAudioTrack,
} from 'agora-rtc-sdk-ng';
import { AGORA_CONFIG, getAgoraChannelName } from '../config/agoraConfig';

// Set Agora log level to warnings/errors only
AgoraRTC.setLogLevel(2);

export interface AgoraCallState {
  channelName: string;
  uid: number;
  isJoined: boolean;
  isAudioMuted: boolean;
  isVideoEnabled: boolean;
  facingMode: 'user' | 'environment';
  connectionState: 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'RECONNECTING' | 'FAILED';
  remoteUserJoined: boolean;
  remoteUid: number | string | null;
  remoteVideoActive: boolean;
  remoteAudioActive: boolean;
  hasLiveToken: boolean;
  tokenMessage: string;
  error: string | null;
}

export type AgoraStateListener = (state: AgoraCallState) => void;

export class AgoraCallManager {
  private static instance: AgoraCallManager;
  private client: IAgoraRTCClient | null = null;
  private localAudioTrack: IMicrophoneAudioTrack | null = null;
  private localVideoTrack: ICameraVideoTrack | null = null;
  private remoteVideoTrack: IRemoteVideoTrack | null = null;
  private remoteAudioTrack: IRemoteAudioTrack | null = null;
  private localContainerId: string = 'agora-local-player';
  private remoteContainerId: string = 'agora-remote-player';
  private listeners: Set<AgoraStateListener> = new Set();

  private state: AgoraCallState = {
    channelName: '',
    uid: 0,
    isJoined: false,
    isAudioMuted: false,
    isVideoEnabled: true,
    facingMode: 'user',
    connectionState: 'DISCONNECTED',
    remoteUserJoined: false,
    remoteUid: null,
    remoteVideoActive: false,
    remoteAudioActive: false,
    hasLiveToken: false,
    tokenMessage: '',
    error: null,
  };

  private constructor() {}

  public static getInstance(): AgoraCallManager {
    if (!AgoraCallManager.instance) {
      AgoraCallManager.instance = new AgoraCallManager();
    }
    return AgoraCallManager.instance;
  }

  public subscribe(listener: AgoraStateListener): () => void {
    this.listeners.add(listener);
    listener({ ...this.state });
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const snapshot = { ...this.state };
    this.listeners.forEach((listener) => listener(snapshot));
  }

  public getState(): AgoraCallState {
    return { ...this.state };
  }

  /**
   * Fetches an RTC token from the secure backend
   */
  public async fetchToken(channelName: string, uid: number): Promise<{ token: string | null; isLiveToken: boolean; message: string }> {
    try {
      const response = await fetch('/api/agora/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelName, uid, role: 'publisher' }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      return {
        token: data.token || null,
        isLiveToken: Boolean(data.isLiveToken),
        message: data.message || 'Token server responded.',
      };
    } catch (err: any) {
      console.warn('Backend Agora token request warning:', err);
      return {
        token: null,
        isLiveToken: false,
        message: 'Direct Agora App ID connection mode active.',
      };
    }
  }

  /**
   * Starts a real one-to-one Agora RTC video call.
   * Both users join the channel, publish their local audio/video tracks,
   * and subscribe to remote participants.
   */
  public async startCall(
    userAIdOrName: string,
    userBIdOrName?: string,
    customRoomName?: string
  ): Promise<boolean> {
    const channelName = getAgoraChannelName(userAIdOrName, userBIdOrName, customRoomName);
    // Unique 32-bit unsigned integer UID per participant session (between 100000 and 999999)
    const uid = Math.floor(Math.random() * 899999) + 100000;

    this.state.channelName = channelName;
    this.state.uid = uid;
    this.state.connectionState = 'CONNECTING';
    this.state.error = null;
    this.state.remoteUserJoined = false;
    this.state.remoteVideoActive = false;
    this.state.remoteAudioActive = false;
    this.notify();

    try {
      // 1. Fetch token from backend (/api/agora/token)
      const tokenInfo = await this.fetchToken(channelName, uid);
      this.state.hasLiveToken = tokenInfo.isLiveToken;
      this.state.tokenMessage = tokenInfo.message;

      // 2. Initialize Agora RTC Client
      this.client = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });

      // 3. Register remote user and stream events
      this.setupClientEvents();

      // 4. Join Agora channel
      await this.client.join(AGORA_CONFIG.appId, channelName, tokenInfo.token, uid);

      // 5. Create local camera and microphone tracks
      const [audioTrack, videoTrack] = await AgoraRTC.createMicrophoneAndCameraTracks(
        {},
        {
          facingMode: this.state.facingMode,
          encoderConfig: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            frameRate: 30,
          },
        }
      );

      this.localAudioTrack = audioTrack;
      this.localVideoTrack = videoTrack;

      // 6. Play local video in the PIP container
      this.playLocalVideo();

      // 7. Publish local audio and video tracks to channel
      await this.client.publish([this.localAudioTrack, this.localVideoTrack]);

      this.state.isJoined = true;
      this.state.connectionState = 'CONNECTED';

      // 8. Subscribe to any participants already in channel
      await this.checkExistingRemoteUsers();

      this.notify();
      return true;
    } catch (err: any) {
      console.error('Agora call initialization error:', err);
      this.state.error = err.message || 'Call connection error';
      this.state.connectionState = 'FAILED';
      this.notify();
      return false;
    }
  }


  private setupClientEvents() {
    if (!this.client) return;

    // 1. Remote user joined channel
    this.client.on('user-joined', (user: IAgoraRTCRemoteUser) => {
      console.log('Agora: Remote user joined channel:', user.uid);
      this.state.remoteUserJoined = true;
      this.state.remoteUid = user.uid;
      this.notify();
    });

    // 2. Remote user published stream (audio or video)
    this.client.on('user-published', async (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
      console.log('Agora: Remote user published track:', user.uid, mediaType);
      try {
        await this.client?.subscribe(user, mediaType);

        this.state.remoteUserJoined = true;
        this.state.remoteUid = user.uid;

        if (mediaType === 'video' && user.videoTrack) {
          this.remoteVideoTrack = user.videoTrack;
          this.state.remoteVideoActive = true;
          this.playRemoteVideo();
        }

        if (mediaType === 'audio' && user.audioTrack) {
          this.remoteAudioTrack = user.audioTrack;
          this.state.remoteAudioActive = true;
          user.audioTrack.play();
        }

        this.notify();
      } catch (subErr) {
        console.error('Agora: Subscription error for remote track:', subErr);
      }
    });

    // 3. Remote user unpublished track
    this.client.on('user-unpublished', (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
      console.log('Agora: Remote user unpublished track:', user.uid, mediaType);
      if (mediaType === 'video') {
        this.state.remoteVideoActive = false;
        this.remoteVideoTrack = null;
      }
      if (mediaType === 'audio') {
        this.state.remoteAudioActive = false;
        this.remoteAudioTrack = null;
      }
      this.notify();
    });

    // 4. Remote user left channel
    this.client.on('user-left', (user: IAgoraRTCRemoteUser, reason: string) => {
      console.log('Agora: Remote user left channel:', user.uid, reason);
      this.state.remoteUserJoined = false;
      this.state.remoteUid = null;
      this.state.remoteVideoActive = false;
      this.state.remoteAudioActive = false;
      this.remoteVideoTrack = null;
      this.remoteAudioTrack = null;
      this.notify();
    });

    // 5. Connection state changes
    this.client.on('connection-state-change', (curState) => {
      if (curState === 'CONNECTED') this.state.connectionState = 'CONNECTED';
      else if (curState === 'CONNECTING') this.state.connectionState = 'CONNECTING';
      else if (curState === 'RECONNECTING') this.state.connectionState = 'RECONNECTING';
      else if (curState === 'DISCONNECTED') this.state.connectionState = 'DISCONNECTED';
      this.notify();
    });
  }

  private async checkExistingRemoteUsers() {
    if (!this.client || this.client.remoteUsers.length === 0) return;

    for (const remoteUser of this.client.remoteUsers) {
      this.state.remoteUserJoined = true;
      this.state.remoteUid = remoteUser.uid;

      if (remoteUser.hasVideo) {
        try {
          await this.client.subscribe(remoteUser, 'video');
          this.remoteVideoTrack = remoteUser.videoTrack || null;
          this.state.remoteVideoActive = true;
          this.playRemoteVideo();
        } catch (e) {
          console.error('Error subscribing to existing remote video:', e);
        }
      }

      if (remoteUser.hasAudio) {
        try {
          await this.client.subscribe(remoteUser, 'audio');
          this.remoteAudioTrack = remoteUser.audioTrack || null;
          this.state.remoteAudioActive = true;
          remoteUser.audioTrack?.play();
        } catch (e) {
          console.error('Error subscribing to existing remote audio:', e);
        }
      }
    }
  }

  /**
   * Plays local video track in the PIP container
   */
  public playLocalVideo(customContainer?: HTMLElement | string | null) {
    const target = customContainer || this.localContainerId;
    const el = typeof target === 'string' ? document.getElementById(target) : target;
    if (el && this.localVideoTrack) {
      try {
        el.innerHTML = '';
        this.localVideoTrack.play(el);
      } catch (err) {
        console.warn('Agora: Local video play warning:', err);
      }
    }
  }

  /**
   * Plays remote video track in the main video area
   */
  public playRemoteVideo(customContainer?: HTMLElement | string | null) {
    const target = customContainer || this.remoteContainerId;
    const el = typeof target === 'string' ? document.getElementById(target) : target;
    if (el && this.remoteVideoTrack) {
      try {
        el.innerHTML = '';
        this.remoteVideoTrack.play(el);
      } catch (err) {
        console.warn('Agora: Remote video play warning:', err);
      }
    }
  }

  public getLocalVideoTrack(): ICameraVideoTrack | null {
    return this.localVideoTrack;
  }

  public getRemoteVideoTrack(): IRemoteVideoTrack | null {
    return this.remoteVideoTrack;
  }


  /**
   * Toggle microphone audio
   */
  public async toggleMicrophone(): Promise<boolean> {
    this.state.isAudioMuted = !this.state.isAudioMuted;
    if (this.localAudioTrack) {
      await this.localAudioTrack.setEnabled(!this.state.isAudioMuted);
    }
    this.notify();
    return this.state.isAudioMuted;
  }

  /**
   * Toggle video camera track
   */
  public async toggleCamera(): Promise<boolean> {
    this.state.isVideoEnabled = !this.state.isVideoEnabled;
    if (this.localVideoTrack) {
      await this.localVideoTrack.setEnabled(this.state.isVideoEnabled);
    }
    this.notify();
    return this.state.isVideoEnabled;
  }

  /**
   * Switch camera between front and rear
   */
  public async switchCameraFacing(customContainer?: HTMLElement | string | null): Promise<'user' | 'environment'> {
    const nextMode = this.state.facingMode === 'user' ? 'environment' : 'user';
    this.state.facingMode = nextMode;

    try {
      if (this.localVideoTrack) {
        const cameras = await AgoraRTC.getCameras();
        if (cameras.length > 1) {
          const currentDeviceId = this.localVideoTrack.getMediaStreamTrack().getSettings().deviceId;
          const otherCamera = cameras.find((c) => c.deviceId !== currentDeviceId) || cameras[0];
          await this.localVideoTrack.setDevice(otherCamera.deviceId);
        } else {
          // Re-create track with facingMode constraint
          if (this.client) {
            await this.client.unpublish([this.localVideoTrack]);
          }
          this.localVideoTrack.stop();
          this.localVideoTrack.close();

          const newTrack = await AgoraRTC.createCameraVideoTrack({
            facingMode: nextMode,
          });
          this.localVideoTrack = newTrack;
          this.playLocalVideo(customContainer);

          if (this.client) {
            await this.client.publish([newTrack]);
          }
        }
      }
    } catch (err) {
      console.warn('Camera switch warning:', err);
    }

    this.notify();
    return nextMode;
  }

  /**
   * End call and clean up all Agora tracks
   */
  public async endCall(): Promise<void> {
    try {
      if (this.localAudioTrack) {
        this.localAudioTrack.stop();
        this.localAudioTrack.close();
        this.localAudioTrack = null;
      }

      if (this.localVideoTrack) {
        this.localVideoTrack.stop();
        this.localVideoTrack.close();
        this.localVideoTrack = null;
      }

      this.remoteVideoTrack = null;
      this.remoteAudioTrack = null;

      if (this.client) {
        await this.client.leave();
        this.client = null;
      }
    } catch (err) {
      console.warn('Error ending Agora call:', err);
    } finally {
      this.state.isJoined = false;
      this.state.connectionState = 'DISCONNECTED';
      this.state.channelName = '';
      this.state.remoteUserJoined = false;
      this.state.remoteUid = null;
      this.state.remoteVideoActive = false;
      this.state.remoteAudioActive = false;
      this.state.error = null;
      this.notify();
    }
  }
}

export const agoraCallManager = AgoraCallManager.getInstance();
